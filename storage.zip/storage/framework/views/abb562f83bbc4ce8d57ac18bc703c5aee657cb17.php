<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Frames</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admin.dashboard.index', $clinic->id)); ?>">Home</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admin.frames.index', $clinic->id)); ?>">
                                Frames
                            </a>
                        </li>
                        <li class="breadcrumb-item active">
                            Frames
                        </li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-lg-6 col-6">
                    <!-- small box -->
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3><?php echo e($num_frames); ?></h3>

                            <p>Frames</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-bag"></i>
                        </div>
                        <a href="#" class="small-box-footer newFrameBtn">New Frame <i class="fa fa-plus"></i></a>
                    </div>
                </div>
                <!-- ./col -->
            </div>
            <!--.row -->

            <div class="row">
                <div class="col-12">
                    <div class="card card-primary card-outline card-outline-tabs">
                        <div class="card-header p-0 border-bottom-0">
                            <ul class="nav nav-tabs" id="custom-tabs-four-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="custom-tabs-four-home-tab" data-toggle="pill"
                                        href="#custom-tabs-four-home" role="tab" aria-controls="custom-tabs-four-home"
                                        aria-selected="true">Frames
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <!--.card-header -->
                        <div class="card-body">
                            <div class="tab-content" id="custom-tabs-four-tabContent">
                                <div class="tab-pane fade show active" id="custom-tabs-four-home" role="tabpanel"
                                    aria-labelledby="custom-tabs-four-home-tab">
                                    <div class="table-responsive">
                                        <table id="framesData" class="table table-striped table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Code</th>
                                                    <th>Brand</th>
                                                    <th>Size</th>
                                                    <th>Type</th>
                                                    <th>Material</th>
                                                    <th>Photo</th>
                                                    <th>Status</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <!--.tab-pane -->
                            </div>
                            <!--.tab-content -->
                        </div>
                        <!--.card-body -->
                    </div>
                    <!-- /.card -->
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div>
        <!--.container-fluid -->

        <!-- Frames Modal -->
        <div class="modal fade" id="newFrameModal">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">New Frame</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="newFrameForm">
                        <div class="modal-body">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="clinic_id" value="<?php echo e($clinic->id); ?>" />
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="newFrameCode">Frame Code </label>
                                        <input type="text" name="code" class="form-control" id="newFrameCode"
                                            placeholder="Enter Frame Code">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="newFrameType">
                                            Frame Type
                                        </label>
                                        <select id="newFrameTypeId" name="type_id" class="form-control select2"
                                            style="width: 100%;">
                                            <option disabled='disabled' selected="selected">
                                                Choose Frame Type
                                            </option>
                                            <?php $__empty_1 = true; $__currentLoopData = $frame_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frame_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option value="<?php echo e($frame_type->id); ?>">
                                                    <?php echo e($frame_type->title); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <option disabled="disabled">No Frame Types Found</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <!-- /.form-group -->
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="newFrameType">
                                            Frame Size
                                        </label>
                                        <select id="newFrameSizeId" name="size_id" class="form-control select2"
                                            style="width: 100%;">
                                            <option disabled='disabled' selected="selected">
                                                Choose Frame Size
                                            </option>
                                            <?php $__empty_1 = true; $__currentLoopData = $frame_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option value="<?php echo e($size->id); ?>">
                                                    <?php echo e($size->size); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <option disabled="disabled">
                                                    No Frame Size found..
                                                </option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="newFrameMaterialId">
                                            Frame Material
                                        </label>
                                        <select id="newFrameMaterialId" name="material_id" class="form-control select2"
                                            style="width: 100%;">
                                            <option disabled='disabled' selected="selected">
                                                Choose Frame Material
                                            </option>
                                            <?php $__empty_1 = true; $__currentLoopData = $frame_materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option value="<?php echo e($material->id); ?>">
                                                    <?php echo e($material->title); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <option disabled="disabled">
                                                    No Frame Materials Found..
                                                </option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <!-- /.form-group -->
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="newFrameBrandId">
                                            Frame Brand
                                        </label>
                                        <select id="newFrameBrandId" name="brand_id" class="form-control select2"
                                            style="width: 100%;">
                                            <option disabled='disabled' selected="selected">
                                                Choose Frame Brand
                                            </option>
                                            <?php $__empty_1 = true; $__currentLoopData = $frame_brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option value="<?php echo e($brand->id); ?>">
                                                    <?php echo e($brand->title); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <option disabled="disabled">No Frame Brand Found..</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="newFramePhoto">Photo</label>
                                        <div class="input-group">
                                            <div class="custom-file">
                                                <input type="file" name="photo" class="custom-file-input"
                                                    id="newFramePhoto" />
                                                <label class="custom-file-label" for="newFramePhoto">Choose
                                                    file</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="newFrameStatus">
                                            Frame Status
                                        </label>
                                        <select id="newFrameStatus" name="status" class="form-control select2"
                                            style="width: 100%;">
                                            <option disabled='disabled' selected="selected">
                                                Choose Frame Status
                                            </option>
                                            <option value="1">Active</option>
                                            <option value="0">Inactive</option>
                                        </select>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default" data-dismiss="modal">
                                Close
                            </button>
                            <button type="submit" id="newFrameSubmitBtn" class="btn btn-primary">
                                Save
                            </button>
                        </div>
                    </form>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->

        <div class="modal fade" id="updateFrameModal">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Update Frame</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="updateFrameForm">
                        <div class="modal-body">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="clinic_id" value="<?php echo e($clinic->id); ?>" />
                            <input type="hidden" name="frame_id" id="updateFrameId" />
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="updateFrameCode">Frame Code </label>
                                        <input type="text" name="code" class="form-control" id="updateFrameCode"
                                            placeholder="Enter Frame Code">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="updateFrameTypeId">
                                            Frame Type
                                        </label>
                                        <select id="updateFrameTypeId" name="type_id" class="form-control select2"
                                            style="width: 100%;">
                                            <option disabled='disabled' selected="selected">
                                                Choose Frame Type
                                            </option>
                                            <?php $__empty_1 = true; $__currentLoopData = $frame_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frame_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option value="<?php echo e($frame_type->id); ?>">
                                                    <?php echo e($frame_type->title); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <option disabled="disabled">No Frame Types Found</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <!-- /.form-group -->
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="updateFrameSizeId">
                                            Frame Size
                                        </label>
                                        <select id="updateFrameSizeId" name="size_id" class="form-control select2"
                                            style="width: 100%;">
                                            <option disabled='disabled' selected="selected">
                                                Choose Frame Size
                                            </option>
                                            <?php $__empty_1 = true; $__currentLoopData = $frame_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option value="<?php echo e($size->id); ?>">
                                                    <?php echo e($size->size); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <option disabled="disabled">
                                                    No Frame Size found..
                                                </option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="updateFrameMaterialId">
                                            Frame Material
                                        </label>
                                        <select id="updateFrameMaterialId" name="material_id"
                                            class="form-control select2" style="width: 100%;">
                                            <option disabled='disabled' selected="selected">
                                                Choose Frame Material
                                            </option>
                                            <?php $__empty_1 = true; $__currentLoopData = $frame_materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option value="<?php echo e($material->id); ?>">
                                                    <?php echo e($material->title); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <option disabled="disabled">
                                                    No Frame Materials Found..
                                                </option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <!-- /.form-group -->
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="updateFrameBrandId">
                                            Frame Brand
                                        </label>
                                        <select id="updateFrameBrandId" name="brand_id" class="form-control select2"
                                            style="width: 100%;">
                                            <option disabled='disabled' selected="selected">
                                                Choose Frame Brand
                                            </option>
                                            <?php $__empty_1 = true; $__currentLoopData = $frame_brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option value="<?php echo e($brand->id); ?>">
                                                    <?php echo e($brand->title); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <option disabled="disabled">No Frame Brand Found..</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="updateFramePhoto">Photo</label>
                                        <div class="input-group">
                                            <div class="custom-file">
                                                <input type="file" name="photo" class="custom-file-input"
                                                    id="updateFramePhoto" />
                                                <label class="custom-file-label" for="updateFramePhoto">Choose
                                                    file</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="updateFrameStatus">
                                            Frame Status
                                        </label>
                                        <select id="updateFrameStatus" name="status" class="form-control select2"
                                            style="width: 100%;">
                                            <option disabled='disabled' selected="selected">
                                                Choose Frame Status
                                            </option>
                                            <option value="1">Active</option>
                                            <option value="0">Inactive</option>
                                        </select>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default" data-dismiss="modal">
                                Close
                            </button>
                            <button type="submit" id="updateFrameSubmitBtn" class="btn btn-primary">
                                Update
                            </button>
                        </div>
                    </form>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->

    </section>
    <!--.content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {

            // Frames sector (Tab)
            find_frames();

            function find_frames() {
                var path = '<?php echo e(route('admin.frames.frames', $clinic->id)); ?>';
                $('#framesData').DataTable({
                    processing: true,
                    serverSide: true,
                    ajax: path,
                    'responsive': true,
                    'autoWidth': false,
                    columns: [{
                            data: 'code',
                            name: 'code'
                        },
                        {
                            data: 'brand',
                            name: 'brand'
                        },
                        {
                            data: 'size',
                            name: 'size'
                        },
                        {
                            data: 'type',
                            name: 'type'
                        },
                        {
                            data: 'material',
                            name: 'material'
                        },
                        {
                            data: 'photo',
                            name: 'photo',
                            orderable: false,
                            searchable: false
                        },
                        {
                            data: 'status',
                            name: 'status'
                        },
                        {
                            data: 'action',
                            name: 'action',
                            orderable: false,
                            searchable: false
                        },
                    ]
                });
            }

            $(document).on('click', '.newFrameBtn', function(e) {
                e.preventDefault();
                $('#newFrameModal').modal('show');
            });

            $('#newFrameForm').submit(function(e) {
                e.preventDefault();
                var form = $(this);
                var formData = new FormData(form[0]);
                var path = '<?php echo e(route('admin.frames.store')); ?>';
                $.ajax({
                    url: path,
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    beforeSend: function() {
                        $('#newFrameSubmitBtn').html('<i class="fa fa-spinner fa-spin"></i>');
                        $('#newFrameSubmitBtn').attr('disabled', true);
                    },
                    complete: function() {
                        $('#newFrameSubmitBtn').html('Save');
                        $('#newFrameSubmitBtn').attr('disabled', false);
                    },
                    success: function(data) {
                        if (data['status']) {
                            toastr.success(data['message']);
                            $('#newFrameModal').modal('hide');
                            $('#newFrameForm')[0].reset();
                            $('#framesData').DataTable().ajax.reload();
                            location.reload();
                        }
                    },
                    error: function(error) {
                        if (error.status == 422) {
                            $.each(error.responseJSON.errors, function(i, error) {
                                toastr.error(error);
                            });
                        } else {
                            toastr.error(error.responseJSON.message);
                        }
                    }
                });
            });

            $(document).on('click', '.deleteFrame', function(e) {
                e.preventDefault();
                var frame_id = $(this).data('id');
                var token = "<?php echo e(csrf_token()); ?>";
                var path = "<?php echo e(route('admin.frames.delete')); ?>";
                Swal.fire({
                    title: "Are you sure?",
                    text: "Once deleted, you will not be able to recover this record!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: path,
                            type: "DELETE",
                            data: {
                                _token: token,
                                frame_id: frame_id
                            },
                            dataType: "json",
                            success: function(data) {
                                if (data['status']) {
                                    Swal.fire(data['message'], '', 'success')
                                    $('#framesData').DataTable().ajax.reload();
                                }
                            }
                        });
                    } else if (result.isDenied) {
                        Swal.fire('Changes are not saved', '', 'info');
                    }
                });
            });

            $(document).on('click', '.editFrame', function(e) {
                e.preventDefault();
                var frame_id = $(this).data('id');
                var path = '<?php echo e(route('admin.frames.show')); ?>';
                $.ajax({
                    url: path,
                    type: 'POST',
                    data: {
                        'frame_id': frame_id,
                        '_token': '<?php echo e(csrf_token()); ?>'
                    },
                    dataType: 'json',
                    success: function(data) {
                        if (data['status']) {
                            $('#updateFrameModal').modal('show');
                            $('#updateFrameId').val(data['data']['id']);
                            $('#updateFrameCode').val(data['data']['code']);
                            $('#updateFrameBrandId').val(data['data']['brand_id']);
                            $('#updateFrameSizeId').val(data['data']['size']);
                            $('#updateFrameTypeId').val(data['data']['type_id']);
                            $('#updateFrameMaterialId').val(data['data']['material_id']);
                            $('#updateFramePhoto').val(data['data']['photo']);
                            $('#updateFrameStatus').val(data['data']['status']);
                        }
                    },
                    error: function(data) {
                        console.log(data);
                    }
                });
            });

            $('#updateFrameForm').submit(function(e) {
                e.preventDefault();
                var form = $(this);
                var formData = new FormData(form[0]);
                var path = '<?php echo e(route('admin.frames.update')); ?>';
                $.ajax({
                    url: path,
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    beforeSend: function() {
                        $('#updateFrameSubmitBtn').html(
                            '<i class="fa fa-spinner fa-spin"></i>');
                        $('#updateFrameSubmitBtn').attr('disabled', true);
                    },
                    complete: function() {
                        $('#updateFrameSubmitBtn').html('Update');
                        $('#updateFrameSubmitBtn').attr('disabled', false);
                    },
                    success: function(data) {
                        if (data['status']) {
                            toastr.success(data['message']);
                            $('#updateFrameModal').modal('hide');
                            $('#updateFrameForm')[0].reset();
                            $('#framesData').DataTable().ajax.reload();
                            location.reload();
                        }
                    },
                    error: function(error) {
                        var errors = data.responseJSON;
                        var errorsHtml = '<ul>';
                        $.each(errors['errors'], function(key, value) {
                            errorsHtml += '<li>' + value + '</li>';
                        });
                        errorsHtml += '</ul>';
                        toastr.error(errorsHtml);
                        console.log(errorsHtml);
                    }
                });
                $.ajaxSetup({
                    statusCode: {
                        401: function(){
                            toastr.error("There is an error");
                        }
                    }
                });
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ewowpvgx/dev/resources/views/admin/frames/frames.blade.php ENDPATH**/ ?>