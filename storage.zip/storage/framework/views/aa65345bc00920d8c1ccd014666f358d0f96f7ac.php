<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark"><?php echo e($clinic->clinic); ?></h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admin.dashboard.index', $clinic->id)); ?>">Home</a>
                        </li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header border-0">
                            <div class="d-flex justify-content-between">
                                <h3 class="card-title">Payments</h3>
                                <a href="<?php echo e(route('admin.payments.bills.index', $clinic->id)); ?>">View Report</a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="d-flex">
                                <p class="d-flex flex-column">
                                    <span class="text-bold text-lg">KSHS <?php echo e(number_format($payments,2)); ?></span>
                                    <span>Total Payments made Over Time</span>
                                </p>
                            </div>
                            <!-- /.d-flex -->

                            <div class="position-relative mb-4">
                                <canvas id="sales-chart" height="200"></canvas>
                            </div>

                            <div class="d-flex flex-row justify-content-end">
                                <span class="mr-2">
                                    <i class="fa fa-square text-primary"></i> This year
                                </span>

                                <span>
                                    <i class="fa fa-square text-gray"></i> Last year
                                </span>
                            </div>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col-md-6 -->
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header border-0">
                            <div class="d-flex justify-content-between">
                                <h3 class="card-title">Remittance</h3>
                                <a href="javascript:void(0);">View Report</a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="d-flex">
                                <p class="d-flex flex-column">
                                    <span class="text-bold text-lg">KSH <?php echo e(number_format($remittances,2)); ?></span>
                                    <span>Total Claimed Remittance</span>
                                </p>
                            </div>
                            <!-- /.d-flex -->

                            <div class="position-relative mb-4">
                                <canvas id="visitors-chart" height="200"></canvas>
                            </div>

                            <div class="d-flex flex-row justify-content-end">
                                <span class="mr-2">
                                    <i class="fa fa-square text-primary"></i> This Week
                                </span>

                                <span>
                                    <i class="fa fa-square text-gray"></i> Last Week
                                </span>
                            </div>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col-md-6 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header border-0">
                            <h3 class="card-title">Appointments</h3>
                        </div>
                        <div class="card-body table-responsive p-0">
                            <table class="table table-striped table-valign-middle">
                                <thead>
                                    <tr>
                                        <th>Patient Names</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Client Type</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td>
                                                <?php echo e($appointment->first_name); ?> <?php echo e($appointment->last_name); ?>

                                            </td>
                                            <td>
                                                <?php echo e($appointment->date); ?>

                                            </td>
                                            <td>
                                                <?php echo e($appointment->appointment_time); ?>

                                            </td>
                                            <td>
                                                <?php echo e($appointment->type); ?>

                                            </td>
                                            <td>
                                                <?php if($appointment->status == 0): ?>
                                                    <span class="badge badge-danger">Not Scheduled</span>
                                                <?php else: ?>
                                                    <span class="badge badge-success">Scheduled</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="#" data-id="<?php echo e($appointment->id); ?>" class="btn btn-tool btn-sm viewAppointmentBtn">
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                            </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="6" class="text-center">
                                                No Appointments added yet
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
            <!--/.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/pages/dashboard3.js')); ?>"></script>
    <script>
        $(document).ready(function() {

            $(document).on('click', '.viewAppointmentBtn', function(e){
                e.preventDefault();
                var appointment_id = $(this).data('id');
                var token = '<?php echo e(csrf_token()); ?>';
                var path = '<?php echo e(route('admin.appointments.show')); ?>';
                $.ajax({
                    url: path,
                    type: 'POST',
                    data: {
                        appointment_id: appointment_id,
                        _token: token
                    },
                    dataType: 'json',
                    success: function(data) {
                        if(data['status']){
                            let url = '<?php echo e(route('admin.appointments.view', $clinic->id)); ?>';
                            setTimeout(() => {
                                window.location.href = url;
                            }, 1000);
                        }
                    },
                    error:function(data){
                        var errors = data.responseJSON;
                        var errorsHtml = '<ul>';
                        $.each(errors['errors'], function(key, value) {
                            errorsHtml += '<li>' + value + '</li>';
                        });
                        errorsHtml += '</ul>';
                        toastr.error(errorsHtml);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ewowpvgx/dev/resources/views/admin/dashboard/index.blade.php ENDPATH**/ ?>