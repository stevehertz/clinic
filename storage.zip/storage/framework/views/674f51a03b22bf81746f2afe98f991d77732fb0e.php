<h1>Forget Password Email</h1>

You can reset password from bellow link:
<br>
<a href="<?php echo e(route('users.reset.password', $token)); ?>">Reset Password</a>
<?php /**PATH /home/ewowpvgx/dev/resources/views/users/mails/forgot-password.blade.php ENDPATH**/ ?>