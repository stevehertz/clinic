<table>
    <thead>
        <tr>
            <th>Clinic</th>
            <th>Patient Names</th>
            <th>Phone Number</th>
            <th>Email Address</th>
            <th>Date of Birth</th>
            <th>Gender</th>
            <th>Address</th>
            <th>Next of Kin</th>
            <th>Next of Kin Contacts</th>
            <th>Appointment Date</th>
            <th>Client Type</th>
            <th>Scheduled Date</th>
            <th>Doctor</th>
            <th>Signs</th>
            <th>Symptoms</th>
            <th>Diagnosis</th>
            <th>Right Sphere</th>
            <th>Right Cylinder</th>
            <th>Right Axis</th>
            <th>Right Add</th>
            <th>Left Sphere</th>
            <th>Left Cylinder</th>
            <th>Left Axis</th>
            <th>Left Add</th>
            <th>Notes</th>
            <th>Index</th>
            <th>Tint</th>
            <th>Diameter</th>
            <th>Focal Height</th>
            <th>Receipt Number</th>
            <th>Frame Code</th>
            <th>Bill Open Date</th>
            <th>Consultation Fee</th>
            <th>Consultation Receipt Number</th>
            <th>Bill Status</th>
            <th>Claimed Amount</th>
            <th>Agreed Amount</th>
            <th>Paid Amount</th>
            <th>Balance</th>
            <th>Order Date</th>
            <th>Order Status</th>
            <th>Workshop</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($report->clinic->clinic); ?></td>
                <td><?php echo e($report->patient->first_name); ?> <?php echo e($report->patient->last_name); ?></td>
                <td><?php echo e($report->patient->phone); ?></td>
                <td><?php echo e($report->patient->email); ?></td>
                <td><?php echo e(date('d-M-Y', strtotime($report->patient->dob))); ?></td>
                <td><?php echo e($report->patient->gender); ?></td>
                <td><?php echo e($report->patient->address); ?></td>
                <td><?php echo e($report->patient->next_of_kin); ?></td>
                <td><?php echo e($report->patient->next_of_kin_contact); ?></td>
                <td><?php echo e(date('d-M-Y', strtotime($report->appointment_date))); ?></td>
                <td><?php echo e($report->payment_detail->client_type->type); ?></td>
                <td>
                    <?php if($report->doctor_schedule): ?>
                        <?php echo e(date('d-M-Y', strtotime($report->doctor_schedule->date))); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->doctor_schedule): ?>
                        <?php echo e($report->doctor_schedule->user->first_name); ?>

                        <?php echo e($report->doctor_schedule->user->last_name); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->diagnosis): ?>
                        <?php echo e($report->diagnosis->signs); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->diagnosis): ?>
                        <?php echo e($report->diagnosis->symptoms); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->diagnosis): ?>
                        <?php echo e($report->diagnosis->diagnosis); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->lens_power): ?>
                        <?php echo e($report->lens_power->right_sphere); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->lens_power): ?>
                        <?php echo e($report->lens_power->right_cylinder); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->lens_power): ?>
                        <?php echo e($report->lens_power->right_axis); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->lens_power): ?>
                        <?php echo e($report->lens_power->right_add); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->lens_power): ?>
                        <?php echo e($report->lens_power->left_sphere); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->lens_power): ?>
                        <?php echo e($report->lens_power->left_cylinder); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->lens_power): ?>
                        <?php echo e($report->lens_power->left_axis); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->lens_power): ?>
                        <?php echo e($report->lens_power->left_add); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->lens_power): ?>
                        <?php echo e($report->lens_power->notes); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->lens_prescription): ?>
                        <?php echo e($report->lens_prescription->index); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->lens_prescription): ?>
                        <?php echo e($report->lens_prescription->tint); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->lens_prescription): ?>
                        <?php echo e($report->lens_prescription->diameter); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->lens_prescription): ?>
                        <?php echo e($report->lens_prescription->focal_height); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->frame_prescription): ?>
                        <?php echo e($report->frame_prescription->receipt_number); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->frame_prescription): ?>
                        <?php echo e($report->frame_prescription->frame_code); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->payment_bill): ?>
                        <?php echo e(date('d-M-Y', strtotime($report->payment_bill->open_date))); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php echo e($report->consultation_fee); ?>

                </td>
                <td>
                    <?php if($report->payment_bill): ?>
                        <?php echo e($report->payment_bill->consultation_receipt_number); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->payment_bill): ?>
                        <?php echo e($report->payment_bill->bill_status); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php echo e($report->claimed_amount); ?>

                </td>
                <td>
                    <?php echo e($report->agreed_amount); ?>

                </td>
                <td>
                    <?php echo e($report->paid_amount); ?>

                </td>
                <td>
                    <?php echo e($report->balance); ?>

                </td>
                <td>
                    <?php if($report->order): ?>
                        <?php echo e(date('d-M-Y', strtotime($report->order->order_date))); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->order): ?>
                        <?php echo e($report->order->status); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if($report->order): ?>
                        <?php echo e($report->order->workshop->name); ?>

                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="43">
                    No Reports Found
                </td>
            </tr>
        <?php endif; ?>
        <tr></tr>
    </tbody>
</table>
<?php /**PATH /home/ewowpvgx/dev/resources/views/admin/clinic_reports/reports.blade.php ENDPATH**/ ?>