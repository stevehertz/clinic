<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>View Closed Bill</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('users.dashboard.index')); ?>">Home</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('users.payments.close.bills.index')); ?>">
                                Closed Bills
                            </a>
                        </li>
                        <li class="breadcrumb-item active">
                            View Closed Bill
                        </li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- Main content -->
                    <div class="invoice p-3 mb-3">

                        <!-- title row -->
                        <div class="row">
                            <div class="col-12">
                                <h4>
                                    <i class="fa fa-globe"></i> <?php echo e($payment_bill->clinic->clinic); ?>

                                    <small class="float-right">Open Date:
                                        <?php echo e(date('d-m-Y', strtotime($payment_bill->open_date))); ?></small>
                                </h4>
                            </div>
                            <!-- /.col -->
                        </div>
                        <!-- info row -->

                        <div class="row invoice-info">
                            <div class="col-sm-4 invoice-col">
                                From
                                <address>
                                    <strong><?php echo e($payment_bill->clinic->clinic); ?></strong><br>
                                    <?php echo e($payment_bill->clinic->address); ?><br>
                                    Phone: <?php echo e($payment_bill->clinic->phone); ?><br>
                                    Email: <?php echo e($payment_bill->clinic->email); ?>

                                </address>
                            </div>
                            <!-- /.col -->

                            <div class="col-sm-4 invoice-col">
                                To
                                <address>
                                    <strong><?php echo e($payment_bill->patient->first_name); ?>

                                        <?php echo e($payment_bill->patient->last_name); ?></strong><br>
                                    <?php echo e($payment_bill->patient->address); ?><br>
                                    Phone: <?php echo e($payment_bill->patient->phone); ?><br>
                                    Email: <?php echo e($payment_bill->patient->email); ?>

                                </address>
                            </div>
                            <!-- /.col -->


                            <div class="col-sm-4 invoice-col">
                                <?php if($payment_bill->invoice_number): ?>
                                    <b>Invoice #<?php echo e($payment_bill->invoice_number); ?></b><br>
                                    <br>
                                    <?php if($payment_bill->lpo_number): ?>
                                        <b>LPO #:</b> <?php echo e($payment_bill->lpo_number); ?><br>
                                    <?php endif; ?>
                                    <b>Open Date:</b> <?php echo e(date('d-M-Y', strtotime($payment_bill->open_date))); ?><br>
                                <?php endif; ?>
                                <b>Bill Status:</b>
                                <?php if($payment_bill->bill_status == 'PENDING'): ?>
                                    <span class="badge badge-warning">
                                        <?php echo e($payment_bill->bill_status); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="badge badge-success">
                                        <?php echo e($payment_bill->bill_status); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <!-- /.col -->

                        </div>
                        <!-- /.row -->

                        <hr>

                        <div class="row">
                            <div class="col-md-6">
                                <h5>Consultation Fee:</h5>
                                <p class="text-lead">
                                    <strong>
                                        <?php echo e(number_format($payment_bill->consultation_fee, 2, '.', ',')); ?>

                                    </strong>
                                </p>
                            </div>
                            <div class="col-md-6">
                                <h5>Consultation Receipt Number:</h5>
                                <p class="text-lead">
                                    <strong>
                                        <?php echo e($payment_bill->consultation_receipt_number); ?>

                                    </strong>
                                </p>
                            </div>
                        </div>

                        <!-- Table row -->
                        <div class="row">
                            <h5>Payments</h5>
                            <div class="col-12 table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Item</th>
                                            <th>Receipt #</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $payment_bill->billing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $billing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($billing->item); ?></td>
                                                <td><?php echo e($billing->receipt_number); ?></td>
                                                <td><?php echo e(number_format($billing->amount, 2, '.', ',')); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="3">
                                                    <p class="text-center">No Payments</p>
                                                </td>
                                            </tr>
                                        <?php endif; ?>

                                    </tbody>
                                </table>
                            </div>
                            <!-- /.col -->
                        </div>
                        <!-- /.row -->

                        <br>

                        <div class="row">
                            <!-- accepted payments column -->
                            <div class="col-12 col-md-6">
                                <p class="lead">Client Type:</p>
                                <?php if($payment_bill->payment_detail->insurance): ?>
                                    <?php echo e($payment_bill->payment_detail->client_type->type); ?>:
                                    <?php echo e($payment_bill->payment_detail->insurance->title); ?> <br>
                                    Approval Number: <?php echo e($payment_bill->approval_number); ?> <br>
                                    Approval Status: <?php if($payment_bill->approval_status == 'APPROVED'): ?>
                                        <span class="badge badge-success"><?php echo e($payment_bill->approval_status); ?></span>
                                    <?php elseif($payment_bill->approval_status == 'PENDING'): ?>
                                        <span class="badge badge-warning"><?php echo e($payment_bill->approval_status); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-danger"><?php echo e($payment_bill->approval_status); ?></span>
                                    <?php endif; ?>
                                    <br>
                                <?php else: ?>
                                    <?php echo e($payment_bill->payment_detail->client_type->type); ?>

                                <?php endif; ?>
                                <br><br>
                                <p class="lead">Remittance</p>
                                <div class="table-responsive">
                                    <table class="table">
                                        <tr>
                                            <th style="width:50%">
                                                Remittance Amount
                                            </th>
                                            <td>
                                                <?php echo e(number_format($payment_bill->remittance_amount, 2, '.', ',')); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <th>
                                                Remittance Balance
                                            </th>
                                            <td>
                                                <?php echo e(number_format($payment_bill->remittance_balance, 2, '.', ',')); ?>

                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <!-- /.col -->

                            <div class="col-12 col-md-6">
                                <?php if($payment_bill->close_date): ?>
                                    <p class="lead">
                                        Closed Date: <?php echo e(date('d-M-Y', strtotime($payment_bill->close_date))); ?>

                                    </p>
                                <?php endif; ?>


                                <div class="table-responsive">
                                    <table class="table">
                                        <tr>
                                            <th style="width:50%">
                                                Claimed Amount
                                            </th>
                                            <td>
                                                <?php echo e(number_format($payment_bill->claimed_amount, 2, '.', ',')); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <?php if( $payment_bill->approval_status == 'REJECTED' ): ?>
                                                <th>
                                                    Rejected Amount
                                                </th>
                                            <?php else: ?>
                                                <th>
                                                    Agreed Amount
                                                </th>
                                            <?php endif; ?>
                                            <td>
                                                <?php echo e(number_format($payment_bill->agreed_amount, 2, '.', ',')); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <th>
                                                Total Amount <br>
                                                <small>Including consultation fee</small>
                                            </th>
                                            <td>
                                                <?php echo e(number_format($payment_bill->total_amount, 2, '.', ',')); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <th>
                                                Paid Amount
                                                <br>
                                                <small>Including consultation fee</small>
                                            </th>
                                            <td>
                                                <?php echo e(number_format($payment_bill->paid_amount, 2, '.', ',')); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Balance</th>
                                            <td>
                                                <?php echo e(number_format($payment_bill->balance, 2, '.', ',')); ?>

                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <!-- /.col -->
                        </div>
                        <!-- /.row -->

                        <!-- this row will not appear when printing -->
                        <div class="row no-print">
                            <div class="col-12">
                                <?php if(!$payment_bill->lpo_number): ?>
                                    <a href="#" data-id='<?php echo e($payment_bill->id); ?>'
                                        class="btn btn-default updateLPONumberBtn">
                                        <i class="fa fa-industry"></i> Add LPO Number
                                    </a>
                                <?php endif; ?>


                                <a href="#" data-id='<?php echo e($payment_bill->id); ?>'
                                    class="btn btn-success createRemittanceBtn">
                                    <i class="fa fa-money"></i> Claim Remittance
                                </a>

                                <button type="button" data-id="<?php echo e($payment_bill->id); ?>"
                                    class="btn btn-warning float-right printPaymentsBtn" style="margin-right: 5px;">
                                    <i class="fa fa-print"></i> Print
                                </button>
                            </div>
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.invoice -->
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->

        <!-- /send bill to remittance -->
        <div class="modal fade" id="updateLPONumberModal">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">
                            Update LPO Number
                        </h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="updateLPONumberForm">
                        <div class="modal-body">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input type="hidden" id="updateLPONumberBillId" name="bill_id" class="form-control">
                            </div>

                            <div class="form-group">
                                <label for="updateLPONumber">
                                    LPO Number
                                </label>
                                <input type="text" name="lpo_number" class="form-control" id="updateLPONumber"
                                    placeholder="Enter LPO Number">
                            </div>
                        </div>
                        <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" id="updateLPONumberSubmitBtn" class="btn btn-primary">
                                Update
                            </button>
                        </div>
                    </form>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->

        <!-- /send bill to remittance -->
        <div class="modal fade" id="createRemittanceModal">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">
                            Claim Remittance
                        </h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="createRemittanceForm">
                        <div class="modal-body">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input type="hidden" id="createRemittanceBillId" name="bill_id" class="form-control">
                            </div>

                            <div class="form-group">
                                <label for="createRemittanceItem">
                                    Item
                                </label>
                                <input type="text" name="item" class="form-control" id="createRemittanceItem"
                                    placeholder="Can be consultation fee, balance, deposit">
                            </div>

                            <div class="form-group">
                                <label for="createRemittanceAmount">
                                    Remittance Amount
                                </label>
                                <input type="number" name="remittance_amount" class="form-control"
                                    id="createRemittanceAmount" placeholder="Remittance Amount">
                            </div>

                            <div class="form-group">
                                <label for="createRemittanceDate">
                                    Remittance Date
                                </label>
                                <input type="text" name="remittance_date" class="form-control datepicker"
                                    id="createRemittanceDate" placeholder="Remittance Date">
                            </div>
                        </div>
                        <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" id="createRemittanceSubmitBtn" class="btn btn-primary">
                                Save
                            </button>
                        </div>
                    </form>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->

    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {

            $(document).on('click', '.updateLPONumberBtn', function(e) {
                e.preventDefault();
                var bill_id = $(this).data('id');
                var token = '<?php echo e(csrf_token()); ?>';
                var path = '<?php echo e(route('users.payments.close.bills.show')); ?>';
                $.ajax({
                    url: path,
                    type: 'POST',
                    data: {
                        bill_id: bill_id,
                        _token: token
                    },
                    success: function(data) {
                        if (data['status']) {
                            $('#updateLPONumberBillId').val(data['data']['id']);
                            $('#updateLPONumberModal').modal('show');
                        }
                    },
                    error: function(data) {
                        var errors = data.responseJSON;
                        var errorsHtml = '<ul>';
                        $.each(errors['errors'], function(key, value) {
                            errorsHtml += '<li>' + value + '</li>';
                        });
                        errorsHtml += '</ul>';
                        toastr.error(errorsHtml);
                    }
                });
            });

            $('#updateLPONumberForm').submit(function(e) {
                e.preventDefault();
                var form = $(this);
                var formData = new FormData(form[0]);
                var path = '<?php echo e(route('users.payments.close.bills.update.lpo')); ?>';
                $.ajax({
                    url: path,
                    type: 'POST',
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    beforeSend: function() {
                        $('#updateLPONumberSubmitBtn').html(
                            '<i class="fa fa-spinner fa-spin"></i>'
                        );
                        $('#updateLPONumberSubmitBtn').attr('disabled', true);
                    },
                    complete: function() {
                        $('#updateLPONumberSubmitBtn').html(
                            'Update'
                        );
                        $('#updateLPONumberSubmitBtn').attr('disabled', false);
                    },
                    success: function(data) {
                        if (data['status']) {
                            $('#updateLPONumberModal').modal('hide');
                            toastr.success(data['message']);
                            setTimeout(function() {
                                window.location.reload();
                            }, 1000);
                        }
                    },
                    error: function(data) {
                        var errors = data.responseJSON;
                        var errorsHtml = '<ul>';
                        $.each(errors['errors'], function(key, value) {
                            errorsHtml += '<li>' + value + '</li>';
                        });
                        errorsHtml += '</ul>';
                        toastr.error(errorsHtml);
                    }
                });

            });

            $(document).on('click', '.printPaymentsBtn', function(e) {
                e.preventDefault();
                var bill_id = $(this).data('id');
                var token = '<?php echo e(csrf_token()); ?>';
                var path = '<?php echo e(route('users.payments.close.bills.show')); ?>';
                $.ajax({
                    url: path,
                    type: 'POST',
                    data: {
                        bill_id: bill_id,
                        _token: token
                    },
                    dataType: 'json',
                    success: function(data) {
                        if (data['status']) {
                            let url = '<?php echo e(route('users.payments.close.bills.print', ':id')); ?>';
                            url = url.replace(':id', data['data']['id']);
                            setTimeout(() => {
                                window.open(url, '_blank');
                            }, 1000);
                        }
                    },
                    error: function(data) {
                        var errors = data.responseJSON;
                        var errorsHtml = '<ul>';
                        $.each(errors['errors'], function(key, value) {
                            errorsHtml += '<li>' + value + '</li>';
                        });
                        errorsHtml += '</ul>';
                        toastr.error(errorsHtml);
                    }
                });
            });

            $(document).on('click', '.createRemittanceBtn', function(e) {
                e.preventDefault();
                var bill_id = $(this).data('id');
                var token = '<?php echo e(csrf_token()); ?>';
                var path = '<?php echo e(route('users.payments.close.bills.show')); ?>';
                $.ajax({
                    url: path,
                    type: 'POST',
                    data: {
                        bill_id: bill_id,
                        _token: token
                    },
                    success: function(data) {
                        if (data['status']) {
                            $('#createRemittanceBillId').val(data['data']['id']);
                            $('#createRemittanceModal').modal('show');
                        }
                    },
                    error: function(data) {
                        var errors = data.responseJSON;
                        var errorsHtml = '<ul>';
                        $.each(errors['errors'], function(key, value) {
                            errorsHtml += '<li>' + value + '</li>';
                        });
                        errorsHtml += '</ul>';
                        toastr.error(errorsHtml);
                    }
                });
            });

            $('#createRemittanceForm').submit(function(e) {
                e.preventDefault();
                var form = $(this);
                var formData = new FormData(form[0]);
                var path = '<?php echo e(route('users.payments.remittance.store')); ?>';
                $.ajax({
                    url: path,
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    beforeSend: function() {
                        $('#createRemittanceSubmitBtn').html(
                            '<i class="fa fa-spinner fa-spin"></i>');
                        $('#createRemittanceSubmitBtn').attr('disabled', true);
                    },
                    complete: function() {
                        $('#createRemittanceSubmitBtn').html('Save');
                        $('#createRemittanceSubmitBtn').attr('disabled', false);
                    },
                    success: function(data) {
                        if (data['status']) {
                            toastr.success(data['message']);
                            $('#createRemittanceForm')[0].reset();
                            $('#createRemittanceModal').modal('hide');
                            update_remittance();
                        }
                    },
                    error: function(data) {
                        var errors = data.responseJSON;
                        var errorsHtml = '<ul>';
                        $.each(errors['errors'], function(key, value) {
                            errorsHtml += '<li>' + value + '</li>';
                        });
                        errorsHtml += '</ul>';
                        toastr.error(errorsHtml);
                    }
                });
            });

            function update_remittance() {
                var bill_id = '<?php echo e($payment_bill->id); ?>';
                var token = '<?php echo e(csrf_token()); ?>';
                var path = '<?php echo e(route('users.payments.remittance.update.bill')); ?>';
                $.ajax({
                    url: path,
                    type: 'POST',
                    data: {
                        bill_id: bill_id,
                        _token: token
                    },
                    dataType: 'json',
                    success: function(data) {
                        if (data['status']) {
                            let url = '<?php echo e(route('users.payments.remittance.index')); ?>';
                            setTimeout(function() {
                                window.location.href = url;
                            }, 1000);
                        }
                    },
                    error: function(data) {
                        var errors = data.responseJSON;
                        var errorsHtml = '<ul>';
                        $.each(errors['errors'], function(key, value) {
                            errorsHtml += '<li>' + value + '</li>';
                        });
                        errorsHtml += '</ul>';
                        toastr.error(errorsHtml);
                    }
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ewowpvgx/dev/resources/views/users/closed/view.blade.php ENDPATH**/ ?>