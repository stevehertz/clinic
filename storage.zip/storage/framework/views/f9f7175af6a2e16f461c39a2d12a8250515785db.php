<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo e(config('app.name')); ?> | <?php echo e($page_title); ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap 4 -->

    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('fonts/font-awesome/css/font-awesome.min.css')); ?>">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('css/adminlte.min.css')); ?>">

    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>

<body>
    <div class="wrapper">
        <!-- Main content -->
        <section class="invoice">
            <!-- title row -->
            <div class="row">
                <div class="col-12">
                    <h2 class="page-header">
                        <i class="fa fa-globe"></i> <?php echo e($payment_bill->clinic->clinic); ?>

                        <small class="float-right">
                            Open Date: <?php echo e(date('d-m-Y', strtotime($payment_bill->open_date))); ?>

                        </small>
                    </h2>
                </div>
                <!-- /.col -->
            </div>
            <!-- info row -->
            <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                    From
                    <address>
                        <strong><?php echo e($payment_bill->clinic->clinic); ?></strong><br>
                        <?php echo e($payment_bill->clinic->address); ?><br>
                        Phone: <?php echo e($payment_bill->clinic->phone); ?><br>
                        Email: <?php echo e($payment_bill->clinic->email); ?>

                    </address>
                </div>
                <!-- /.col -->

                <div class="col-sm-4 invoice-col">
                    To
                    <address>
                        <strong><?php echo e($payment_bill->patient->first_name); ?>

                            <?php echo e($payment_bill->patient->last_name); ?></strong><br>
                        <?php echo e($payment_bill->patient->address); ?><br>
                        Phone: <?php echo e($payment_bill->patient->phone); ?><br>
                        Email: <?php echo e($payment_bill->patient->email); ?>

                    </address>
                </div>
                <!-- /.col -->

                <div class="col-sm-4 invoice-col">
                    <?php if($payment_bill->invoice_number): ?>
                        <b>Invoice #<?php echo e($payment_bill->invoice_number); ?></b><br>
                        <br>
                        <b>LPO #:</b> <?php echo e($payment_bill->lpo_number); ?><br>
                        <b>Open Date:</b> <?php echo e(date('d-m-Y', strtotime($payment_bill->open_date))); ?><br>
                    <?php endif; ?>
                    <b>Bill Status:</b>
                    <?php if($payment_bill->bill_status == 'PENDING'): ?>
                        <span class="badge badge-warning">
                            <?php echo e($payment_bill->bill_status); ?>

                        </span>
                    <?php else: ?>
                        <span class="badge badge-success">
                            <?php echo e($payment_bill->bill_status); ?>

                        </span>
                    <?php endif; ?>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->

            <hr>

            <div class="row">
                <div class="col-md-6">
                    <h5>Consultation Fee:</h5>
                    <p class="text-lead">
                        <strong>
                            <?php echo e(number_format($payment_bill->consultation_fee, 2, '.', ',')); ?>

                        </strong>
                    </p>
                </div>
                <div class="col-md-6">
                    <h5>Consultation Receipt Number:</h5>
                    <p class="text-lead">
                        <strong>
                            <?php echo e($payment_bill->consultation_receipt_number); ?>

                        </strong>
                    </p>
                </div>
            </div>

            <!-- Table row -->
            <div class="row">
                <h5>Payments</h5>
                <div class="col-12 table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Item</th>
                                <th>Receipt #</th>
                                <th>Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $payment_bill->billing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $billing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($billing->item); ?></td>
                                    <td><?php echo e($billing->receipt_number); ?></td>
                                    <td><?php echo e(number_format($billing->amount, 2, '.', ',')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3">
                                        <p class="text-center">No Payments</p>
                                    </td>
                                </tr>
                            <?php endif; ?>

                        </tbody>
                    </table>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->

            <br>

            <div class="row">
                <!-- accepted payments column -->
                <div class="col-12 col-md-6">
                    <p class="lead">Client Type:</p>
                    <?php if($payment_bill->payment_detail->insurance): ?>
                        <?php echo e($payment_bill->payment_detail->client_type->type); ?>:
                        <?php echo e($payment_bill->payment_detail->insurance->title); ?> <br>
                        Approval Number: <?php echo e($payment_bill->approval_number); ?> <br>
                        Approval Status: <?php if($payment_bill->approval_status == 'APPROVED'): ?>
                            <span class="badge badge-success"><?php echo e($payment_bill->approval_status); ?></span>
                        <?php elseif($payment_bill->approval_status == 'PENDING'): ?>
                            <span class="badge badge-warning"><?php echo e($payment_bill->approval_status); ?></span>
                        <?php else: ?>
                            <span class="badge badge-danger"><?php echo e($payment_bill->approval_status); ?></span>
                        <?php endif; ?>
                        <br>
                    <?php else: ?>
                        <?php echo e($payment_bill->payment_detail->client_type->type); ?>

                    <?php endif; ?>

                    <br><br>
                    <h5>Remarks</h5>
                    <p class="text-muted well well-sm shadow-none" style="margin-top: 10px;">
                        <?php echo e($payment_bill->remarks); ?>

                    </p>
                </div>
                <!-- /.col -->
                <div class="col-12 col-md-6">
                    <?php if($payment_bill->closing_date): ?>
                        <p class="lead">
                            Closing Date: <?php echo e(date('d-m-Y', strtotime($payment_bill->close_date))); ?>

                        </p>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table class="table">
                            <tr>
                                <th style="width:50%">
                                    Claimed Amount
                                </th>
                                <td>
                                    <?php echo e(number_format($payment_bill->claimed_amount, 2, '.', ',')); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>
                                    Agreed Amount
                                </th>
                                <td>
                                    <?php echo e(number_format($payment_bill->agreed_amount, 2, '.', ',')); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>
                                    Total Amount <br>
                                    <small>Including consultation fee</small>
                                </th>
                                <td>
                                    <?php echo e(number_format($payment_bill->total_amount, 2, '.', ',')); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>
                                    Paid Amount
                                    <br>
                                    <small>Including consultation fee</small>
                                </th>
                                <td>
                                    <?php echo e(number_format($payment_bill->paid_amount, 2, '.', ',')); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>Balance</th>
                                <td>
                                    <?php echo e(number_format($payment_bill->balance, 2, '.', ',')); ?>

                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- ./wrapper -->

    <script type="text/javascript">
        window.addEventListener("load", window.print());
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\clinic\resources\views/admin/bills/print.blade.php ENDPATH**/ ?>