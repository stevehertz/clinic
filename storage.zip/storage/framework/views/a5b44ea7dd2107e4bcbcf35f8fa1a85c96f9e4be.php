<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Order</h1>
                    <small>
                        Order Date: <?php echo e(date('d-m-Y', strtotime($order->order_date))); ?>

                    </small>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('users.dashboard.index')); ?>">Home</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('users.orders.index')); ?>">
                                Orders
                            </a>
                        </li>
                        <li class="breadcrumb-item active">
                            View Order
                        </li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-3">

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            Lens Power
                        </h3>

                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                    class="fa fa-minus"></i>
                            </button>
                        </div>
                    </div>

                    <div class="card-body table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <td></td>
                                    <td>Rigth Eye</td>
                                    <td>Left Eye</td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Sphere</td>
                                    <td><?php echo e($order->lens_power->right_sphere); ?></td>
                                    <td><?php echo e($order->lens_power->left_sphere); ?></td>
                                </tr>
                                <tr>
                                    <td>Cylinder</td>
                                    <td><?php echo e($order->lens_power->right_cylinder); ?></td>
                                    <td><?php echo e($order->lens_power->left_cylinder); ?></td>
                                </tr>
                                <tr>
                                    <td>Axis</td>
                                    <td><?php echo e($order->lens_power->right_axis); ?></td>
                                    <td><?php echo e($order->lens_power->left_axis); ?></td>
                                </tr>
                                <tr>
                                    <td>Additional</td>
                                    <td><?php echo e($order->lens_power->right_add); ?></td>
                                    <td><?php echo e($order->lens_power->left_add); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            Frame Code
                        </h3>

                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                    class="fa fa-minus"></i>
                            </button>
                        </div>
                    </div>

                    <div class="card-body table-responsive">
                        <p>
                            <?php echo e($order->frame_prescription->frame_code); ?>

                        </p>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <div class="col-md-6">
                <div class="card card-outline card-primary">
                    <div class="card-header p-2">
                        <ul class="nav nav-pills">

                            <li class="nav-item">
                                <a class="nav-link active" href="#lensPrescriptionTab" data-toggle="tab">
                                    Lens Prescription
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="#orderDetailsTab" data-toggle="tab">
                                    Order Details
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="#trackOrderTab" data-toggle="tab">
                                    Track Order
                                </a>
                            </li>
                        </ul>
                    </div><!-- /.card-header -->
                    <div class="card-body">
                        <div class="tab-content">
                            <div class="active tab-pane" id="lensPrescriptionTab">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <tbody>
                                            <tr>
                                                <th>Lens Type</th>
                                                <td>
                                                    <?php echo e($order->lens_prescription->lens_type->type); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <th>Lens Material</th>
                                                <td>
                                                    <?php echo e($order->lens_prescription->lens_material->title); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <th>Lens Index/Thickness</th>
                                                <td>
                                                    <?php echo e($order->lens_prescription->index); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <th>Tint</th>
                                                <td>
                                                    <?php echo e($order->lens_prescription->tint); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <th>Diameter</th>
                                                <td>
                                                    <?php echo e($order->lens_prescription->diameter); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <th>Focal Height</th>
                                                <td>
                                                    <?php echo e($order->lens_prescription->focal_height); ?>

                                                </td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div class="tab-pane" id="orderDetailsTab">
                                <strong><i class="fa fa-calendar mr-1"></i> Date</strong>

                                <p class="text-muted">
                                    <?php echo e(date('d-m-Y', strtotime($order->order_date))); ?>

                                </p>

                                <hr>

                                <strong><i class="fa fa-sticky-note mr-1"></i> Order Receipt</strong>

                                <p class="text-muted">
                                    <?php echo e($order->receipt_number); ?>

                                </p>

                                <hr>

                                <strong><i class="fa fa-cog mr-1"></i> Status</strong>

                                <p class="text-muted">
                                    <?php echo e($order->status); ?>

                                </p>

                            </div>
                            <!-- /.tab-pane -->

                            <div class="tab-pane" id="trackOrderTab">
                                <?php if($order->status == 'APPROVED'): ?>
                                    <button type="button" data-id="<?php echo e($order->id); ?>" data-value="SENT TO WORKSHOP"
                                        class="btn btn-block btn-success orderSentToWorkshopBtn">
                                        <i class="fa fa-send"></i> ORDER SENT TO WORKSHOP
                                    </button>
                                <?php elseif($order->status == 'SENT TO WORKSHOP'): ?>
                                    <button type="button" data-id="<?php echo e($order->id); ?>"
                                        data-value="FRAME SENT TO WORKSHOP"
                                        class="btn btn-block btn-primary orderfRAMESentToWorkshopBtn">
                                        <i class="fa fa-send"></i> FRAME SENT TO WORKSHOP
                                    </button>
                                <?php elseif($order->status == 'FRAME SENT TO WORKSHOP'): ?>
                                    <button type="button" data-id="<?php echo e($order->id); ?>"
                                        data-value="FRAME RECEIVED FROM WORKSHOP"
                                        class="btn btn-block btn-info orderfRAMEReceivedFromWorkshopBtn">
                                        <i class="fa fa-send"></i> FRAME RECEIVED FROM WORKSHOP
                                    </button>
                                <?php elseif($order->status == 'FRAME RECEIVED FROM WORKSHOP'): ?>
                                    <button type="button" data-id="<?php echo e($order->id); ?>" data-value="COLLECTED"
                                        class="btn btn-block btn-success orderfRAMECollectedBtn">
                                        <i class="fa fa-send"></i> FRAME COLLECTED
                                    </button>
                                <?php elseif($order->status == 'COLLECTED'): ?>
                                    <button type="button" data-id="<?php echo e($order->id); ?>" data-value="CLOSE"
                                        class="btn btn-block btn-danger orderCloseBtn">
                                        <i class="fa fa-send"></i> CLOSE ORDER
                                    </button>
                                <?php endif; ?>

                                <br>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Doctor</th>
                                                <th>Status</th>
                                                <th>Workshop</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $order->order_track; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $track): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e(date('d-m-Y', strtotime($track->track_date))); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($track->user->first_name); ?> <?php echo e($track->user->last_name); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($track->track_status); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($track->workshop->name); ?>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <?php endif; ?>
                                        </tbody>

                                    </table>
                                </div>
                            </div>
                            <!-- /.tab-pane -->
                        </div>
                        <!-- /.tab-content -->
                    </div><!-- /.card-body -->
                </div>
                <!-- /.nav-tabs-custom -->
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            Order For Patient
                        </h3>

                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                    class="fa fa-minus"></i>
                            </button>
                        </div>
                    </div>

                    <div class="card-body p-0">
                        <ul class="nav nav-pills flex-column">
                            <li class="nav-item active">
                                <a href="#" class="nav-link">
                                    <i class="fa fa-user"></i> <?php echo e($order->patient->first_name); ?>

                                    <?php echo e($order->patient->last_name); ?>

                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link">
                                    <i class="fa fa-phone"></i> <?php echo e($order->patient->phone); ?>

                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link">
                                    <i class="fa fa-envelope"></i> <?php echo e($order->patient->email); ?>

                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link">
                                    <i class="fa fa-calendar"></i> <?php echo e($order->patient->dob); ?>

                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link">
                                    <i class="fa fa-male"></i> <?php echo e($order->patient->gender); ?>

                                </a>
                            </li>

                            <li class="nav-item">
                                <a href="#" class="nav-link">
                                    <i class="fa fa-map-signs"></i> <?php echo e($order->patient->address); ?>

                                </a>
                            </li>
                        </ul>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Doctor/ Optimist</h3>

                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                    class="fa fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <ul class="nav nav-pills flex-column">
                            <li class="nav-item">
                                <a href="#" class="nav-link">
                                    <i class="fa fa-user text-danger"></i>
                                    <?php echo e($order->doctor_schedule->user->first_name); ?>

                                    <?php echo e($order->doctor_schedule->user->last_name); ?>

                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link">
                                    <i class="fa fa-phone text-warning"></i> <?php echo e($order->doctor_schedule->user->phone); ?>

                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link">
                                    <i class="fa fa-envelope text-primary"></i>
                                    <?php echo e($order->doctor_schedule->user->email); ?>

                                </a>
                            </li>
                        </ul>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->

            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {

            $(document).on('click', '.orderSentToWorkshopBtn', function(e) {
                e.preventDefault();
                var order_id = $(this).data('id');
                var token = '<?php echo e(csrf_token()); ?>';
                var status = $(this).data('value');
                var path = '<?php echo e(route('users.orders.update', $order->id)); ?>';

                Swal.fire({
                    title: "Are you sure?",
                    text: "You are about to move order to workshop!",
                    icon: "success",
                    buttons: true,
                    dangerMode: true,
                }).then((result) => {
                    /* Read more about isConfirmed, isDenied below */
                    if (result.isConfirmed) {
                        $.ajax({
                            url: path,
                            type: 'POST',
                            data: {
                                order_id: order_id,
                                status: status,
                                _token: token
                            },
                            dataType: "json",
                            success: function(data) {
                                if (data['status']) {
                                    toastr.success(data['message']);
                                    setTimeout(() => {
                                        window.location.reload();
                                    }, 1000);
                                }
                            },

                        });
                    } else if (result.isDenied) {
                        Swal.fire('Changes are not saved', '', 'info');
                    }
                });
            });

            $(document).on('click', '.orderfRAMESentToWorkshopBtn', function(e) {
                e.preventDefault();
                var order_id = $(this).data('id');
                var token = '<?php echo e(csrf_token()); ?>';
                var status = $(this).data('value');
                var path = '<?php echo e(route('users.orders.update', $order->id)); ?>';

                Swal.fire({
                    title: "Are you sure?",
                    text: "You are about to move frame to workshop!",
                    icon: "success",
                    buttons: true,
                    dangerMode: true,
                }).then((result) => {
                    /* Read more about isConfirmed, isDenied below */
                    if (result.isConfirmed) {
                        $.ajax({
                            url: path,
                            type: 'POST',
                            data: {
                                order_id: order_id,
                                status: status,
                                _token: token
                            },
                            dataType: "json",
                            success: function(data) {
                                if (data['status']) {
                                    toastr.success(data['message']);
                                    setTimeout(() => {
                                        window.location.reload();
                                    }, 1000);
                                }
                            },

                        });
                    } else if (result.isDenied) {
                        Swal.fire('Changes are not saved', '', 'info');
                    }
                });
            });

            $(document).on('click', '.orderfRAMEReceivedFromWorkshopBtn', function(e) {
                e.preventDefault();
                var order_id = $(this).data('id');
                var token = '<?php echo e(csrf_token()); ?>';
                var status = $(this).data('value');
                var path = '<?php echo e(route('users.orders.update', $order->id)); ?>';
                Swal.fire({
                    title: "Are you sure?",
                    text: "You are about to move frame to workshop!",
                    icon: "success",
                    buttons: true,
                    dangerMode: true,
                }).then((result) => {
                    /* Read more about isConfirmed, isDenied below */
                    if (result.isConfirmed) {
                        $.ajax({
                            url: path,
                            type: 'POST',
                            data: {
                                order_id: order_id,
                                status: status,
                                _token: token
                            },
                            dataType: "json",
                            success: function(data) {
                                if (data['status']) {
                                    toastr.success(data['message']);
                                    send_patient();
                                }
                            },

                        });
                    } else if (result.isDenied) {
                        Swal.fire('Changes are not saved', '', 'info');
                    }
                });
            });

            function send_patient() {
                var order_id = '<?php echo e($order->id); ?>';
                var token = '<?php echo e(csrf_token()); ?>';
                var path = '<?php echo e(route('users.orders.send.mail')); ?>';
                $.ajax({
                    url: path,
                    type: 'POST',
                    data: {
                        order_id: order_id,
                        _token: token
                    },
                    dataType: "json",
                    success: function(data) {
                        if (data['status']) {
                            setTimeout(() => {
                                window.location.reload();
                            }, 1000);
                        }
                    },
                    error: function(data) {
                        var errors = data.responseJSON;
                        var errorsHtml = '<ul>';
                        $.each(errors['errors'], function(key, value) {
                            errorsHtml += '<li>' + value + '</li>';
                        });
                        errorsHtml += '</ul>';
                        toastr.error(errorsHtml);
                    }
                });
            }

            $(document).on('click', '.orderfRAMECollectedBtn', function(e) {
                e.preventDefault();
                var order_id = $(this).data('id');
                var token = '<?php echo e(csrf_token()); ?>';
                var status = $(this).data('value');
                var path = '<?php echo e(route('users.orders.update', $order->id)); ?>';
                Swal.fire({
                    title: "Are you sure?",
                    text: "You are about to move frame to workshop!",
                    icon: "success",
                    buttons: true,
                    dangerMode: true,
                }).then((result) => {
                    /* Read more about isConfirmed, isDenied below */
                    if (result.isConfirmed) {
                        $.ajax({
                            url: path,
                            type: 'POST',
                            data: {
                                order_id: order_id,
                                status: status,
                                _token: token
                            },
                            dataType: "json",
                            success: function(data) {
                                if (data['status']) {
                                    toastr.success(data['message']);
                                    setTimeout(() => {
                                        window.location.reload();
                                    }, 1000);
                                }
                            },

                        });
                    } else if (result.isDenied) {
                        Swal.fire('Changes are not saved', '', 'info');
                    }
                });
            });

            $(document).on('click', '.orderCloseBtn', function(e) {
                e.preventDefault();
                var order_id = $(this).data('id');
                var token = '<?php echo e(csrf_token()); ?>';
                var status = $(this).data('value');
                var path = '<?php echo e(route('users.orders.update', $order->id)); ?>';
                Swal.fire({
                    title: "Are you sure?",
                    text: "You are about to move frame to workshop!",
                    icon: "success",
                    buttons: true,
                    dangerMode: true,
                }).then((result) => {
                    /* Read more about isConfirmed, isDenied below */
                    if (result.isConfirmed) {
                        $.ajax({
                            url: path,
                            type: 'POST',
                            data: {
                                order_id: order_id,
                                status: status,
                                _token: token
                            },
                            dataType: "json",
                            success: function(data) {
                                if (data['status']) {
                                    toastr.success(data['message']);
                                    setTimeout(() => {
                                        window.location.reload();
                                    }, 1000);
                                }
                            },

                        });
                    } else if (result.isDenied) {
                        Swal.fire('Changes are not saved', '', 'info');
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ewowpvgx/dev/resources/views/users/orders/view.blade.php ENDPATH**/ ?>