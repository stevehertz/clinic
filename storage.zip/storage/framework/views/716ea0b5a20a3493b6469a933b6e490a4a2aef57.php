<?php $__env->startComponent('mail::message'); ?>
    <h2>Hello <?php echo e($details['name']); ?></h2>
    An account has been created for you on the <?php echo e(config('app.name')); ?> system.
    <br>
    Your account details are below:
    <br>
    Email: <?php echo e($details['email']); ?> <br>
    Password: <?php echo e($details['password']); ?> <br>
    Please click the link below to login and change your password.
    <p>
        <?php $__env->startComponent('mail::button', ['url' => $details['url']]); ?>
            Login
        <?php echo $__env->renderComponent(); ?>
    </p>

<?php echo $__env->renderComponent(); ?>

<?php /**PATH C:\xampp\htdocs\clinic\resources\views/admin/mails/users.blade.php ENDPATH**/ ?>