<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>View Remittance</h1>
                    <small><?php echo e($clinic->clinic); ?></small>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admin.dashboard.index', $clinic->id)); ?>">Home</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admin.payments.remittance.index', $clinic->id)); ?>">Remittance</a>
                        </li>
                        <li class="breadcrumb-item active">View Remittance</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3">
                    <!-- About Me Box -->
                    <div class="card card-primary card-outline">
                        <div class="card-header">
                            <h3 class="card-title">Patient Details</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <strong><i class="fa fa-user mr-1"></i> Full Names</strong>

                            <p class="text-muted">
                                <?php echo e($payment_bill->patient->first_name); ?> <?php echo e($payment_bill->patient->last_name); ?>

                            </p>

                            <hr>

                            <strong><i class="fa fa-phone mr-1"></i> Phone Number</strong>

                            <p class="text-muted">
                                <?php echo e($payment_bill->patient->phone); ?>

                            </p>

                            <hr>

                            <strong><i class="fa fa-envelope mr-1"></i> Email Address</strong>

                            <p class="text-muted">
                                <?php echo e($payment_bill->patient->email); ?>

                            </p>

                            <hr>

                            <strong><i class="fa fa-map-pin mr-1"></i> Address</strong>

                            <p class="text-muted"><?php echo e($payment_bill->patient->address); ?></p>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->

                </div>
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-12">
                            <!-- Main content -->
                            <div class="invoice p-3 mb-3">

                                <!-- title row -->
                                <div class="row">
                                    <div class="col-12">
                                        <h4>
                                            Remittance Bill
                                            <small class="float-right">Claimed Date:
                                                <?php echo e(date('d-M-Y', strtotime($remittance->remittance_date))); ?></small>
                                        </h4>
                                    </div>
                                    <!-- /.col -->
                                </div>
                                <!-- info row -->
                                <br>

                                <div class="row invoice-info">
                                    <div class="col-sm-6 invoice-col">
                                        From:
                                        <address>
                                            <strong><?php echo e($remittance->clinic->organization->organization); ?></strong><br>
                                            <br>
                                            Phone: <?php echo e($remittance->clinic->organization->phone); ?><br>
                                            Email: <?php echo e($remittance->clinic->organization->email); ?>

                                        </address>
                                    </div>
                                    <!-- /.col -->

                                    <div class="col-sm-6 invoice-col">
                                        To:
                                        <address>
                                            <strong><?php echo e($remittance->clinic->clinic); ?></strong><br>
                                            <br>
                                            Phone: <?php echo e($remittance->clinic->phone); ?><br>
                                            Email: <?php echo e($remittance->clinic->email); ?>

                                        </address>
                                    </div>
                                    <!-- /.col -->


                                </div>
                                <!-- Table row -->
                                <br>
                                
                                <!-- /.row -->
                                <br>
                                <div class="row">
                                    <!-- accepted payments column -->
                                    <div class="col-12 col-md-6">
                                        <p class="lead">Remittance Status:</p>
                                        <?php if($remittance->status == 'OPENED'): ?>
                                            <span class="badge badge-primary"><?php echo e($remittance->status); ?></span>
                                        <?php else: ?>
                                            <span class="badge badge-success"><?php echo e($remittance->status); ?></span>
                                        <?php endif; ?>
                                        <br><br>
                                        <p class="lead">Claimed Item:</p>
                                        <?php echo e($remittance->item); ?>

                                    </div>
                                    <!-- /.col -->
                                    <div class="col-12 col-md-6">
                                        <p class="lead">
                                            <?php if($remittance->closed_date): ?>
                                                Closed Date: <?php echo e(date('d-m-Y', strtotime($payment_bill->close_date))); ?>

                                            <?php endif; ?>
                                        </p>
                                        <div class="table-responsive">
                                            <table class="table">
                                                <tr>
                                                    <th style="width:50%">
                                                        Claimed Amount
                                                    </th>
                                                    <td>
                                                        <?php echo e(number_format($remittance->amount, 2, '.', ',')); ?>

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th style="width:50%">
                                                        Paid Amount
                                                    </th>
                                                    <td>
                                                        <?php echo e(number_format($remittance->paid, 2, '.', ',')); ?>

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th style="width:50%">
                                                        Balance
                                                    </th>
                                                    <td>
                                                        <?php echo e(number_format($remittance->balance, 2, '.', ',')); ?>

                                                    </td>
                                                </tr>
                                            </table>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-md-3">
                    <!-- About Me Box -->
                    <div class="card card-primary card-outline">
                        <div class="card-header">
                            <h3 class="card-title">Bill Details</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <strong><i class="fa fa-database mr-1"></i> Invoice Number</strong>

                            <p class="text-muted">
                                <?php echo e($payment_bill->invoice_number); ?>

                            </p>

                            <hr>

                            <strong><i class="fa fa-industry mr-1"></i> LPO Number</strong>

                            <p class="text-muted">
                                <?php echo e($payment_bill->lpo_number); ?>

                            </p>

                            <hr>

                            <strong><i class="fa fa-calendar mr-1"></i> Open Date</strong>

                            <p class="text-muted">
                                <?php echo e(date('d-M-Y', strtotime($payment_bill->open_date))); ?>

                            </p>

                            <hr>

                            <strong><i class="fa fa-cc mr-1"></i> Consultation Fee</strong>

                            <p class="text-muted">
                                <?php echo e($payment_bill->consultation_fee); ?>

                            </p>

                            <hr>

                            <strong><i class="fa fa-money mr-1"></i> Agreed Amount</strong>

                            <p class="text-muted">
                                <?php echo e($payment_bill->agreed_amount); ?>

                            </p>

                            <hr>

                            <strong><i class="fa fa-money mr-1"></i> Total Amount</strong>

                            <p class="text-muted">
                                <?php echo e($payment_bill->consultation_fee); ?>

                            </p>

                            <hr>

                            <strong><i class="fa fa-money mr-1"></i> Paid Amounr</strong>

                            <p class="text-muted">
                                <?php echo e($payment_bill->paid_amount); ?>

                            </p>

                            <hr>
                            <strong><i class="fa fa-calendar mr-1"></i> Closing Date</strong>

                            <p class="text-muted">
                                <?php echo e(date('d-M-Y', strtotime($payment_bill->close_date))); ?>

                            </p>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->

                </div>
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic\resources\views/admin/remittance/view.blade.php ENDPATH**/ ?>