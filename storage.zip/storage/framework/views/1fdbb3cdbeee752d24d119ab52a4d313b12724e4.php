<table>
    <thead>
        <tr>
            <th>Full Names</th>
            <th>Appointment Date</th>
            <th>Time</th>
            <th>Client Type</th>
            <th>Insurance</th>
            <th>Scheme Name</th>
            <th>Insurance No.</th>
            <th>Workplace</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($appointment->patient->first_name); ?> <?php echo e($appointment->patient->last_name); ?></td>
                <td><?php echo e($appointment->date); ?></td>
                <td><?php echo e($appointment->appointment_time); ?></td>
                <td><?php echo e($appointment->payment_detail->client_type->type); ?></td>
                <td>
                    <?php if($appointment->payment_detail->insurance): ?>
                        <?php echo e($appointment->payment_detail->insurance->title); ?>

                    <?php endif; ?>
                </td>
                <td><?php echo e($appointment->payment_detail->scheme); ?></td>
                <td><?php echo e($appointment->card_number); ?></td>
                <td><?php echo e($appointment->payment_detail->principal_workplace); ?></td>
                <td><?php echo e($appointment->status); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="9">
                    No Appointment data found..
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\clinic\resources\views/admin/appointments/reports.blade.php ENDPATH**/ ?>