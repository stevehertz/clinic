<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?php echo e($clinic->clinic); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admin.dashboard.index', $clinic->id)); ?>">Home</a>
                        </li>
                        <li class="breadcrumb-item active">
                            Settings
                        </li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3">

                    <!-- Profile Image -->
                    <div class="card card-primary card-outline">
                        <div class="card-body box-profile">
                            <div class="text-center">
                                <img class="profile-user-img img-fluid img-circle" src="<?php echo e(asset('storage/clinics/'.$clinic->logo)); ?>"
                                    alt="User profile picture">
                            </div>

                            <h3 class="profile-username text-center">
                                <?php echo e($clinic->clinic); ?>

                            </h3>

                            <p class="text-muted text-center">
                                <?php echo e($clinic->initials); ?>

                            </p>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->

                    <!-- About Me Box -->
                    <div class="card card-primary">
                        <div class="card-body">
                            <strong><i class="fa fa-envelope mr-1"></i> Email Address</strong>

                            <p class="text-muted">
                                <?php echo e($clinic->email); ?>

                            </p>

                            <hr>

                            <strong><i class="fa fa-phone mr-1"></i> Phone Number</strong>

                            <p class="text-muted">
                                <?php echo e($clinic->phone); ?>

                            </p>

                            <hr>

                            <strong><i class="fa fa-map-signs mr-1"></i> Address</strong>

                            <p class="text-muted">
                                <?php echo e($clinic->address); ?>

                            </p>

                            <hr>

                            <strong><i class="fa fa-map mr-1"></i> Location</strong>

                            <p class="text-muted">
                                <?php echo e($clinic->location); ?>

                            </p>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->

                <div class="col-md-9">
                    <div class="card">
                        <div class="card-header p-2">
                            <ul class="nav nav-pills">
                                <li class="nav-item">
                                    <a class="nav-link active" href="#updateClinicTab" data-toggle="tab">
                                        Update Clinic
                                    </a>
                                </li>
                            </ul>
                        </div><!-- /.card-header -->
                        <div class="card-body">
                            <div class="tab-content">
                                <div class="active tab-pane" id="updateClinicTab">
                                    <form id="updateClinicForm" role="form">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" value="<?php echo e($clinic->id); ?>" name="clinic_id" />
                                        <div class="form-group">
                                            <label for="updateClinicName">Clinic Name</label>
                                            <input type="text" class="form-control" value="<?php echo e($clinic->clinic); ?>" id="updateClinicName" name="clinic" placeholder="Clinic Name">
                                        </div>

                                        <div class="form-group">
                                            <label for="updateClinicLogo">Logo</label>
                                            <div class="input-group">
                                                <div class="custom-file">
                                                    <input type="file" name="logo" class="custom-file-input"
                                                        id="updateClinicLogo">
                                                    <label class="custom-file-label" for="updateClinicLogo">
                                                        Choose file
                                                    </label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="updateClinicInitials">Clinic Initials</label>
                                            <input type="text" class="form-control" value="<?php echo e($clinic->initials); ?>" id="updateClinicInitials" name="initials" placeholder="Clinic Initials">
                                        </div>

                                        <div class="form-group">
                                            <label for="updateClinicPhone">Phone Number</label>
                                            <input type="text" class="form-control" value="<?php echo e($clinic->phone); ?>" id="updateClinicPhone" name="phone" placeholder="Phone Number">
                                        </div>

                                        <div class="form-group">
                                            <label for="updateClinicEmail">Email Address</label>
                                            <input type="email" value="<?php echo e($clinic->email); ?>" name="email" class="form-control" id="updateClinicEmail">
                                        </div>



                                        <div class="form-group">
                                            <label for="updateClinicAddress">Address</label>
                                            <textarea name="address" id="updateClinicAddress" class="form-control" placeholder="Enter Clinic's Address"><?php echo e($clinic->address); ?></textarea>
                                        </div>

                                        <div class="form-group">
                                            <label for="updateClinicLocation">Location</label>
                                            <input type="text" value="<?php echo e($clinic->location); ?>" name="location"
                                                class="form-control" id="updateClinicLocation">
                                        </div>

                                        <div class="form-group">
                                            <button type="submit" id="updateClinicSubmitBtn"
                                                class="btn btn-primary btn-block">UPDATE</button>
                                        </div>
                                    </form>
                                </div>
                                <!-- /.tab-pane -->
                            </div>
                            <!-- /.tab-content -->
                        </div><!-- /.card-body -->
                    </div>
                    <!-- /.nav-tabs-custom -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
    $(document).ready(function(){

        $('#updateClinicForm').submit(function(e){
            e.preventDefault();
            $('#updateClinicSubmitBtn').html('<i class="fa fa-spinner fa-spin"></i>');
            $('#updateClinicSubmitBtn').attr('disabled', true);
            var path = '<?php echo e(route('admin.clinics.update')); ?>';
            var formData = new FormData(this);
            $.ajax({
                url: path,
                method: 'POST',
                data: formData,
                contentType: false,
                cache: false,
                processData: false,
                success: function(data){
                    $('#updateClinicSubmitBtn').html('UPDATE');
                    $('#updateClinicSubmitBtn').attr('disabled', false);
                    if(data['status']){
                        toastr.success(data.message);
                        setTimeout(function(){
                            window.location.reload();
                        }, 2000);
                    }else{
                        console.log(data);
                    }
                }
            });
        });

    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic\resources\views/admin/clinics/view.blade.php ENDPATH**/ ?>