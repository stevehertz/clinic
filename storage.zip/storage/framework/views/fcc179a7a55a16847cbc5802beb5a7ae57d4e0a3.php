<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>

<body>
    <table style="width:100%;">
        <thead>
            <tr>
                <th>Full Names</th>
                <th>ID Number</th>
                <th>Telephone</th>
                <th>Email Address</th>
                <th>Date of Birth</th>
                <th>Gender</th>
                <th>Address</th>
                <th>Next of Kin</th>
                <th>Next of Kin Contacts</th>
                <th>Added By</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($patient->first_name); ?> <?php echo e($patient->last_name); ?></td>
                    <td><?php echo e($patient->id_number); ?> </td>
                    <td><?php echo e($patient->phone); ?> </td>
                    <td><?php echo e($patient->email); ?> </td>
                    <td><?php echo e($patient->dob); ?> </td>
                    <td><?php echo e($patient->gender); ?> </td>
                    <td><?php echo e($patient->address); ?> </td>
                    <td><?php echo e($patient->next_of_kin); ?> </td>
                    <td><?php echo e($patient->next_of_kin_contact); ?> </td>
                    <td><?php echo e($patient->user->first_name); ?> <?php echo e($patient->user->last_name); ?> </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="11">No Patient Data Found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\clinic\resources\views/admin/patients/reports.blade.php ENDPATH**/ ?>