<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?> Profile</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('users.dashboard.index')); ?>">Home</a>
                        </li>
                        <li class="breadcrumb-item active">User Profile</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3">
                    <!-- Profile Image -->
                    <div class="card card-primary card-outline">
                        <div class="card-body box-profile">
                            <div class="text-center">
                                <img class="profile-user-img img-fluid img-circle"
                                    src="<?php echo e(asset('storage/users/noimage.png')); ?>" alt="<?php echo e($user->username); ?>">
                            </div>

                            <h3 class="profile-username text-center"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>

                            </h3>

                            <p class="text-muted text-center"><?php echo e($user->username); ?></p>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->

                    <!-- About Me Box -->
                    <div class="card card-primary">
                        <div class="card-body">
                            <strong><i class="fa fa-phone mr-1"></i> Phone Number</strong>

                            <p class="text-muted">
                                <?php echo e($user->phone); ?>

                            </p>

                            <hr>

                            <strong><i class="fa fa-envelope mr-1"></i> Email Address</strong>

                            <p class="text-muted"><?php echo e($user->email); ?></p>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->

                <div class="col-md-9">
                    <div class="card card-primary card-outline">
                        <div class="card-header p-2">
                            <ul class="nav nav-pills">
                                <li class="nav-item">
                                    <a class="nav-link active" href="#updateProfileTab" data-toggle="tab">
                                        Update Profile
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#changePasswordTab" data-toggle="tab">
                                        Change Password
                                    </a>
                                </li>
                            </ul>
                        </div><!-- /.card-header -->
                        <div class="card-body">
                            <div class="tab-content">
                                <div class="active tab-pane" id="updateProfileTab">
                                    <form id="updateProfileForm" role="form">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label for="updateProfileFirstName">First Name</label>
                                            <input type="text" class="form-control" value="<?php echo e($user->first_name); ?>"
                                                name="first_name" id="updateProfileFirstName">
                                        </div>

                                        <div class="form-group">
                                            <label for="updateProfileLastName">Last Name</label>
                                            <input type="text" class="form-control" value="<?php echo e($user->last_name); ?>"
                                                name="last_name" id="updateProfileLastName">
                                        </div>

                                        <div class="form-group">
                                            <label for="updateProfilePhone">Phone Number</label>
                                            <input type="text" value="<?php echo e($user->phone); ?>" name="phone"
                                                class="form-control" id="updateProfilePhone">
                                        </div>

                                        <div class="form-group">
                                            <label for="updateProfileEmail">Email Address</label>
                                            <input type="email" value="<?php echo e($user->email); ?>" name="email"
                                                class="form-control" id="updateProfileEmail">
                                        </div>

                                        <div class="form-group">
                                            <label for="updateProfileUsername">Username</label>
                                            <input type="text" value="<?php echo e($user->username); ?>" name="username"
                                                class="form-control" id="updateProfileUsername">
                                        </div>

                                        <div class="form-group">
                                            <button type="submit" id="updateProfileSubmitBtn"
                                                class="btn btn-primary btn-block">UPDATE</button>
                                        </div>
                                    </form>
                                </div>
                                <!-- /.tab-pane -->

                                <div class="tab-pane" id="changePasswordTab">
                                    <!-- The timeline -->
                                    <form id="changePasswordForm" role="form">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label for="changePasswordCurrentPassword">Current Password</label>
                                            <input type="password" class="form-control" name="current_password"
                                                placeholder="Enter Current Password" id="changePasswordCurrentPassword">
                                        </div>

                                        <div class="form-group">
                                            <label for="changePasswordNewPassword">New Password</label>
                                            <input type="password" class="form-control" placeholder="Enter new password"
                                                name="new_password" id="changePasswordNewPassword">
                                        </div>

                                        <div class="form-group">
                                            <label for="changePasswordConfirmPassword">Confirm Password</label>
                                            <input type="password" placeholder="Retype Password" name="confirm_password"
                                                class="form-control" id="changePasswordConfirmPassword">
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" id="changePasswordSubmitPassword"
                                                class="btn btn-primary btn-block">
                                                UPDATE PASSWORD
                                            </button>
                                        </div>
                                    </form>
                                </div>
                                <!-- /.tab-pane -->
                            </div>
                            <!-- /.tab-content -->
                        </div><!-- /.card-body -->
                    </div>
                    <!-- /.nav-tabs-custom -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {

            $('#updateProfileForm').submit(function(e){
                e.preventDefault();
                let form = $(this);
                var formData = new FormData(form[0]);
                var path = '<?php echo e(route('users.users.update')); ?>';
                $.ajax({
                    url:path,
                    type:'POST',
                    data:formData,
                    contentType:false,
                    processData:false,
                    dataType:"json",
                    beforeSend:function(){
                        $('#updateProfileSubmitBtn').html('<i class="fa fa-spinner fa-spin"></i>');
                        $('#updateProfileSubmitBtn').attr('disabled',true);
                    },
                    complete:function(){
                        $('#updateProfileSubmitBtn').html('UPDATE');
                        $('#updateProfileSubmitBtn').attr('disabled',false);
                    },
                    success:function(data){
                        if(data['status']){
                            toastr.success(data['message']);
                            setTimeout(() => {
                                location.reload();
                            }, 1000);
                        }else{
                            console.log(data);
                        }
                    }
                });
            });

            $('#changePasswordForm').submit(function(e){
                e.preventDefault();
                let form = $(this);
                var formData = new FormData(form[0]);
                var path = '<?php echo e(route('users.users.update.password')); ?>';
                $.ajax({
                    url:path,
                    type:'POST',
                    data:formData,
                    contentType:false,
                    processData:false,
                    dataType:"json",
                    beforeSend:function(){
                        $('#changePasswordSubmitPassword').html('<i class="fa fa-spinner fa-spin"></i>');
                        $('#changePasswordSubmitPassword').attr('disabled',true);
                    },
                    complete:function(){
                        $('#changePasswordSubmitPassword').html('UPDATE PASSWORD');
                        $('#changePasswordSubmitPassword').attr('disabled',false);
                    },
                    success:function(data){
                        if(data['status']){
                            toastr.success(data['message']);
                            setTimeout(() => {
                                location.reload();
                            }, 1000);
                        }else{
                            console.log(data);
                        }
                    }
                });
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ewowpvgx/dev/resources/views/users/user/index.blade.php ENDPATH**/ ?>