<?php $__env->startComponent('mail::message'); ?>
    <?php echo e($details['title']); ?>


    <?php echo e($details['body']); ?>


    Thanks,<br>
    <?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/ewowpvgx/dev/resources/views/users/mails/orders.blade.php ENDPATH**/ ?>