<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?php echo e($patient->first_name); ?> <?php echo e($patient->last_name); ?> Profile</h1>
                    <small>Added By: <?php echo e($patient->user->first_name); ?> <?php echo e($patient->user->last_name); ?></small><br>
                    <small><?php echo e($clinic->clinic); ?></small>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admin.dashboard.index', $clinic->id)); ?>">Home</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admin.patients.index', $clinic->id)); ?>">Patients</a>
                        </li>
                        <li class="breadcrumb-item active">Patient Profile</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3">
                    <!-- About Me Box -->
                    <div class="card card-primary">
                        <div class="card-body">
                            <strong><i class="fa fa-user mr-1"></i> Full Names</strong>

                            <p class="text-muted">
                                <?php echo e($patient->first_name); ?> <?php echo e($patient->last_name); ?>

                            </p>

                            <hr>

                            <strong><i class="fa fa-phone mr-1"></i> Telephone Number</strong>

                            <p class="text-muted">
                                <?php echo e($patient->phone); ?>

                            </p>

                            <hr>

                            <strong><i class="fa fa-envelope mr-1"></i> Email Address</strong>

                            <p class="text-muted">
                                <?php echo e($patient->email); ?>

                            </p>

                            <hr>

                            <strong><i class="fa fa-calendar mr-1"></i> Date of Birth</strong>

                            <p class="text-muted">
                                <?php echo e($patient->dob); ?>

                            </p>

                            <hr>

                            <strong><i class="fa fa-user-secret mr-1"></i> Gender</strong>

                            <p class="text-muted">
                                <?php echo e($patient->gender); ?>

                            </p>

                            <hr>

                            <strong><i class="fa fa-map-signs mr-1"></i> Address</strong>

                            <p class="text-muted">
                                <?php echo e($patient->address); ?>

                            </p>


                            <hr>

                            <strong><i class="fa fa-user-plus mr-1"></i> Next of Kin</strong>

                            <p class="text-muted">
                                <?php echo e($patient->next_of_kin); ?>

                            </p>

                            <hr>

                            <strong><i class="fa fa-phone mr-1"></i> Next of Kin Contacts</strong>

                            <p class="text-muted"><?php echo e($patient->next_of_kin_contact); ?></p>

                            <hr>

                            <strong><i class="fa fa-plus-circle mr-1"></i> Added By</strong>

                            <p class="text-muted">
                                <?php echo e($patient->user->first_name); ?> <?php echo e($patient->user->last_name); ?>

                            </p>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
                <div class="col-md-9">
                    <div class="card">
                        <div class="card-header p-2">
                            <ul class="nav nav-pills">
                                <li class="nav-item">
                                    <a class="nav-link active" href="#appointmentsTab" data-toggle="tab">
                                        Appointments
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#doctorScheduleTab" data-toggle="tab">
                                        Previous Schedules
                                    </a>
                                </li>
                            </ul>
                        </div><!-- /.card-header -->
                        <div class="card-body">
                            <div class="tab-content">
                                <div class="active tab-pane" id="appointmentsTab">
                                    <div class="row">
                                        <div class="col-md-12 table-responsive">
                                            <table class="table table-bordered table-striped">
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Time</th>
                                                        <th>Client Type</th>
                                                        <th>Insurance</th>
                                                        <th>Scheme Name</th>
                                                        <th>Insurance No.</th>
                                                        <th>Workplace</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <tr>
                                                            <td>
                                                                <?php echo e($appointment->date); ?>

                                                            </td>
                                                            <td>
                                                                <?php echo e(date('h:i A', strtotime($appointment->appointment_time))); ?>

                                                            </td>
                                                            <td>
                                                                <?php echo e($appointment->payment_detail->client_type->type); ?>

                                                            </td>

                                                            <td>
                                                                <?php if($appointment->payment_detail->insurance): ?>
                                                                    <?php echo e($appointment->payment_detail->insurance->title); ?>

                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <?php if($appointment->payment_detail->insurance): ?>
                                                                    <?php echo e($appointment->payment_detail->scheme); ?>

                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <?php if($appointment->payment_detail->insurance): ?>
                                                                    <?php echo e($appointment->payment_detail->card_number); ?>

                                                                <?php endif; ?>
                                                            </td>

                                                            <td>
                                                                <?php echo e($appointment->payment_detail->principal_workplace); ?>

                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        <tr>
                                                            <td colspan="4">
                                                                <p class="text-center">
                                                                    No Appointments
                                                                </p>
                                                            </td>
                                                        </tr>
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.tab-pane -->

                                <div class="tab-pane" id="doctorScheduleTab">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Doctor</th>
                                                    <th>Schedule Day</th>
                                                    <th>Date</th>
                                                    <th>Time</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td>
                                                            <?php echo e($schedule->user->first_name); ?>

                                                            <?php echo e($schedule->user->last_name); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e($schedule->day); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e(date('d-M-Y', strtotime($schedule->date))); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e(date('h:i A', strtotime($schedule->time))); ?>

                                                        </td>
                                                        <td>
                                                            <a href="#" data-id="<?php echo e($schedule->id); ?>"
                                                                class="btn btn-success viewScheduleBtn">
                                                                <i class="fa fa-eye"></i> View
                                                            </a>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="5">
                                                            <p class="text-center">
                                                                No Schedules
                                                            </p>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <!-- /.tab-pane -->

                            </div>
                            <!-- /.tab-content -->
                        </div><!-- /.card-body -->
                    </div>
                    <!-- /.nav-tabs-custom -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {});
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic\resources\views/admin/patients/view.blade.php ENDPATH**/ ?>