<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Create Doctor</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admin.dashboard.index', $clinic->id)); ?>">Home</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admin.doctors.index', $clinic->id)); ?>">Doctors</a>
                        </li>
                        <li class="breadcrumb-item active">New Doctor</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- left column -->
                <div class="col-md-12">
                    <!-- general form elements -->
                    <div class="card card-primary card-outline">
                        <!-- form start -->
                        <form id="newDoctorForm" role="form">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="<?php echo e($clinic->id); ?>" name="clinic_id" id="newDoctorId"
                                class="form-control" />
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="newDoctorFirstName">First Name</label>
                                            <input type="text" class="form-control" name="first_name"
                                                id="newDoctorFirstName" placeholder="Enter First Name">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="newDoctorLastName">Last Name</label>
                                            <input type="text" class="form-control" name="last_name"
                                                id="newDoctorLastName" placeholder="Enter Last Name">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="newDoctorPhone">Telephone</label>
                                            <input type="text" class="form-control" name="phone" id="newDoctorPhone"
                                                placeholder="Enter Telephone Number">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="newDoctorEmail">Email Address</label>
                                            <input type="email" class="form-control" name="email" id="newDoctorEmail"
                                                placeholder="Enter Email Address">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="newDoctorStatus">Status</label>
                                            <select id="newDoctorStatus" name="status"
                                                class="form-control select2 select2-danger"
                                                data-dropdown-css-class="select2-danger" style="width: 100%;">
                                                <option disabled="disabled" selected="selected">Choose Status</option>
                                                <option value="1">Active</option>
                                                <option value="0">Inactive</option>
                                            </select>
                                        </div>
                                        <!-- /.form-group -->
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                                <button type="submit" id="newDoctorSubmitBtn" class="btn btn-primary btn-block">
                                    Create
                                </button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->



                </div>
                <!--/.col (left) -->

            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#newDoctorForm').submit(function(e) {
                e.preventDefault();
                var form = $(this);
                var formData = new FormData(form[0]);
                var path = '<?php echo e(route('admin.doctors.store')); ?>';
                $.ajax({
                    url: path,
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    beforeSend: function() {
                        $('#newDoctorSubmitBtn').html('<i class="fa fa-spinner fa-spin"></i>');
                        $('#newDoctorSubmitBtn').attr('disabled', true);
                    },
                    complete: function() {
                        $('#newDoctorSubmitBtn').html('Create');
                        $('#newDoctorSubmitBtn').attr('disabled', false);
                    },
                    success: function(data) {
                        if (data['status']) {
                            toastr.success(data['message']);
                            $('#newDoctorForm')[0].reset();
                            var doctorsPath = '<?php echo e(route('admin.doctors.index', $clinic->id)); ?>';
                            setTimeout(function() {
                                window.location.href = doctorsPath;
                            }, 2000);
                        } else {
                            console.log(data);
                        }
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic\resources\views/admin/doctors/create.blade.php ENDPATH**/ ?>