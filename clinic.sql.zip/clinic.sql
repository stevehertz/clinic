-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 08, 2022 at 06:51 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clinic`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `has_organization` tinyint(1) NOT NULL DEFAULT 0,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `first_name`, `last_name`, `profile`, `phone`, `email`, `email_verified_at`, `gender`, `dob`, `has_organization`, `username`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(2, 'Stephen', 'Kamau', 'noimage.png', '0715356718', 'stevekamahertz@gmail.com', NULL, NULL, NULL, 1, 'Admin', '$2y$10$rKJ1IF3kba1i3Xqar8MhD.tQhPdIKs5dLwsJZDx.Z/4lBxq1Q8leq', '7Xfxh9z18Dw74MPToIFbHbC2csZizgmqtDHfvXQvDn8U85Qnw025IuHzUGPz', '2022-09-10 00:09:25', '2022-09-10 00:12:14');

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `clinic_id` bigint(20) UNSIGNED NOT NULL,
  `patient_id` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `appointment_time` time DEFAULT NULL,
  `hq_approval_request_status` int(11) NOT NULL DEFAULT 0,
  `hq_approval_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `report_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assets`
--

CREATE TABLE `assets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `clinic_id` bigint(20) UNSIGNED NOT NULL,
  `type_id` bigint(20) UNSIGNED NOT NULL,
  `condition_id` bigint(20) UNSIGNED NOT NULL,
  `asset` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `serial_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_cost` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `assets`
--

INSERT INTO `assets` (`id`, `clinic_id`, `type_id`, `condition_id`, `asset`, `serial_number`, `quantity`, `description`, `purchase_date`, `purchase_cost`, `created_at`, `updated_at`) VALUES
(1, 4, 6, 6, 'Office Chairs', NULL, 5, NULL, '2022-08-26', '25000.00', '2022-09-10 09:51:17', '2022-09-10 09:51:17'),
(2, 4, 8, 6, 'HP Laptop', '12345', 5, NULL, '2022-07-01', '125000.00', '2022-09-10 09:52:18', '2022-09-10 09:52:18');

-- --------------------------------------------------------

--
-- Table structure for table `asset_conditions`
--

CREATE TABLE `asset_conditions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `asset_conditions`
--

INSERT INTO `asset_conditions` (`id`, `organization_id`, `title`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(4, 2, 'Broken', 'broken', 'Broken', '2022-09-10 00:58:59', '2022-09-10 00:58:59'),
(5, 2, 'Irrepairable', 'irrepairable', 'Irrepairable', '2022-09-10 00:59:08', '2022-09-10 00:59:08'),
(6, 2, 'Working', 'working', 'Working', '2022-09-10 00:59:17', '2022-09-10 00:59:17');

-- --------------------------------------------------------

--
-- Table structure for table `asset_transfers`
--

CREATE TABLE `asset_transfers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `asset_id` bigint(20) UNSIGNED NOT NULL,
  `from_clinic_id` bigint(20) UNSIGNED NOT NULL,
  `to_clinic_id` bigint(20) UNSIGNED NOT NULL,
  `transfer_date` date NOT NULL,
  `type_id` bigint(20) UNSIGNED NOT NULL,
  `condition_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `remarks` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_types`
--

CREATE TABLE `asset_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `asset_types`
--

INSERT INTO `asset_types` (`id`, `organization_id`, `title`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(5, 2, 'Clothes', 'clothes', 'Clothes', '2022-09-10 00:57:18', '2022-09-10 00:57:18'),
(6, 2, 'Furniture', 'furniture', 'Furniture', '2022-09-10 00:57:28', '2022-09-10 00:57:28'),
(7, 2, 'Inventory Books', 'inventory-books', 'Inventory Books', '2022-09-10 00:57:38', '2022-09-10 00:57:38'),
(8, 2, 'Machinery', 'machinery', 'Machinery', '2022-09-10 00:57:47', '2022-09-10 00:57:47');

-- --------------------------------------------------------

--
-- Table structure for table `billings`
--

CREATE TABLE `billings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `payment_bill_id` bigint(20) UNSIGNED NOT NULL,
  `item` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receipt_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `client_types`
--

CREATE TABLE `client_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `client_types`
--

INSERT INTO `client_types` (`id`, `organization_id`, `type`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(4, 2, 'Cash', 'cash', 'Cash', '2022-09-10 00:27:09', '2022-09-10 00:27:09'),
(5, 2, 'Insurance', 'insurance', 'Insurance', '2022-09-10 00:27:44', '2022-09-10 00:27:44'),
(6, 2, 'Cash and Insurance', 'cash-and-insurance', 'Cash and Insurance', '2022-09-10 00:27:58', '2022-09-10 00:27:58');

-- --------------------------------------------------------

--
-- Table structure for table `clinics`
--

CREATE TABLE `clinics` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `clinic` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `initials` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clinics`
--

INSERT INTO `clinics` (`id`, `organization_id`, `clinic`, `logo`, `phone`, `email`, `address`, `location`, `initials`, `created_at`, `updated_at`) VALUES
(3, 2, 'MEDIHEAL', 'mediheal_1662813932.png', '254723578895', 'info@medihealgroup.com', 'P.O. Box 7995 – 30100, Nandi Road, Eldoret, Kenya.', 'Eldoret, Kenya', 'MDH', '2022-09-10 09:45:32', '2022-09-10 09:45:32'),
(4, 2, 'AGAKHAN VOI', 'agakhan_1662814099.png', '0701666667', 'saiseyeclinic@gmail.com', 'VOI', 'VOI', 'AGK', '2022-09-10 09:48:19', '2022-09-10 09:48:19');

-- --------------------------------------------------------

--
-- Table structure for table `colors`
--

CREATE TABLE `colors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `colors`
--

INSERT INTO `colors` (`id`, `organization_id`, `color`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(5, 2, 'Black', 'black-1662783374', 'Black', '2022-09-10 01:13:51', '2022-09-10 01:16:14'),
(6, 2, 'Green', 'green-1662783384', 'Green', '2022-09-10 01:16:24', '2022-09-10 01:16:24'),
(7, 2, 'Red', 'red-1662783394', 'Red', '2022-09-10 01:16:34', '2022-09-10 01:16:34');

-- --------------------------------------------------------

--
-- Table structure for table `contact_lens`
--

CREATE TABLE `contact_lens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `clinic_id` bigint(20) UNSIGNED NOT NULL,
  `type_id` bigint(20) UNSIGNED NOT NULL,
  `material_id` bigint(20) UNSIGNED NOT NULL,
  `item_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `diagnoses`
--

CREATE TABLE `diagnoses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `clinic_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `patient_id` bigint(20) UNSIGNED NOT NULL,
  `appointment_id` bigint(20) UNSIGNED NOT NULL,
  `schedule_id` bigint(20) UNSIGNED NOT NULL,
  `signs` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `symptoms` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `diagnosis` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `doctor_schedules`
--

CREATE TABLE `doctor_schedules` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `clinic_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `patient_id` bigint(20) UNSIGNED NOT NULL,
  `appointment_id` bigint(20) UNSIGNED NOT NULL,
  `day` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `frames`
--

CREATE TABLE `frames` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `clinic_id` bigint(20) UNSIGNED NOT NULL,
  `brand_id` bigint(20) UNSIGNED NOT NULL,
  `type_id` bigint(20) UNSIGNED NOT NULL,
  `size_id` bigint(20) UNSIGNED NOT NULL,
  `material_id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `frames`
--

INSERT INTO `frames` (`id`, `clinic_id`, `brand_id`, `type_id`, `size_id`, `material_id`, `code`, `photo`, `status`, `created_at`, `updated_at`) VALUES
(2, 4, 6, 6, 4, 12, 'oFW5HHoN7H', 'frames_1662814425.jpg', 1, '2022-09-10 09:53:45', '2022-09-10 09:53:45'),
(3, 4, 10, 8, 5, 13, 'q24reS1E1z', 'noimage.png', 1, '2022-09-10 09:54:11', '2022-09-10 09:54:11'),
(5, 4, 11, 11, 5, 15, 'I3uaOdl6zl', 'black_1662841536.jpg', 1, '2022-09-10 17:25:36', '2022-09-10 17:25:36'),
(6, 3, 10, 9, 5, 13, 'gLXpHY6S', 'noimage.png', 1, '2022-09-11 03:42:52', '2022-09-11 03:42:52'),
(7, 3, 6, 11, 4, 12, 'RDSpjCwE', 'noimage.png', 1, '2022-09-11 03:43:22', '2022-09-11 03:43:22'),
(8, 3, 11, 6, 6, 13, '5sEQaiac', 'noimage.png', 1, '2022-09-11 03:44:33', '2022-09-11 03:44:33'),
(9, 3, 12, 7, 4, 12, 'zQoMUtZa', 'noimage.png', 1, '2022-09-11 03:45:15', '2022-09-11 03:45:15'),
(10, 3, 13, 8, 5, 15, 'LhfaFe3e', 'noimage.png', 1, '2022-09-11 03:45:44', '2022-09-11 03:45:44'),
(11, 3, 14, 9, 6, 13, 'FyvDYiXh', 'noimage.png', 1, '2022-09-11 03:46:24', '2022-09-11 03:46:24'),
(12, 3, 15, 10, 4, 14, 'eEQUCmXv', 'noimage.png', 1, '2022-09-11 03:46:57', '2022-09-11 03:46:57'),
(13, 3, 15, 10, 4, 14, '4nfsAQLr', 'noimage.png', 1, '2022-09-11 03:55:26', '2022-09-11 03:55:26');

-- --------------------------------------------------------

--
-- Table structure for table `frame_brands`
--

CREATE TABLE `frame_brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `frame_brands`
--

INSERT INTO `frame_brands` (`id`, `organization_id`, `title`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(1, 1, 'Eden Walters', 'eden-walters', 'Eden Walters', '2022-09-03 02:44:05', '2022-09-03 02:44:05'),
(2, 1, 'QLOO', 'qloo', 'QLOO', '2022-09-03 02:44:15', '2022-09-03 02:44:15'),
(3, 1, 'RAYBAN', 'rayban', 'RAYBAN', '2022-09-03 02:44:25', '2022-09-03 02:44:25'),
(4, 1, 'Reese Bird', 'reese-bird', 'Reese Bird', '2022-09-03 02:44:35', '2022-09-03 02:44:35'),
(5, 1, 'Timon Carson', 'timon-carson', 'Timon Carson', '2022-09-03 02:44:49', '2022-09-03 02:44:49'),
(6, 2, 'Carolina Herrera', 'carolina-herrera-1662782854', 'Carolina Herrera', '2022-09-10 01:03:18', '2022-09-10 01:07:34'),
(10, 2, 'Eden Walters', 'eden-walters-1662782755', 'Eden Walters', '2022-09-10 01:05:55', '2022-09-10 01:05:55'),
(11, 2, 'QLOO', 'qloo-1662782791', 'QLOO', '2022-09-10 01:06:31', '2022-09-10 01:06:31'),
(12, 2, 'Ray Ban', 'ray-ban-1662782805', 'Ray Ban', '2022-09-10 01:06:45', '2022-09-10 01:06:45'),
(13, 2, 'Reese Bird', 'reese-bird-1662782821', 'Reese Bird', '2022-09-10 01:07:01', '2022-09-10 01:07:01'),
(14, 2, 'Timon Carson', 'timon-carson-1662782832', 'Timon Carson', '2022-09-10 01:07:12', '2022-09-10 01:07:12'),
(15, 2, 'Tommy Hilfiger', 'tommy-hilfiger-1662782842', 'Tommy Hilfiger', '2022-09-10 01:07:22', '2022-09-10 01:07:22');

-- --------------------------------------------------------

--
-- Table structure for table `frame_colors`
--

CREATE TABLE `frame_colors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `frame_colors`
--

INSERT INTO `frame_colors` (`id`, `organization_id`, `color`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(7, 2, 'Black', 'black', 'Black', '2022-09-10 01:09:54', '2022-09-10 01:09:54'),
(8, 2, 'Brown', 'brown', 'Brown', '2022-09-10 01:10:06', '2022-09-10 01:10:06'),
(9, 2, 'Green', 'green', 'Green', '2022-09-10 01:10:20', '2022-09-10 01:10:20'),
(10, 2, 'Red', 'red', 'Red', '2022-09-10 01:10:28', '2022-09-10 01:10:28');

-- --------------------------------------------------------

--
-- Table structure for table `frame_materials`
--

CREATE TABLE `frame_materials` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `frame_materials`
--

INSERT INTO `frame_materials` (`id`, `organization_id`, `title`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(12, 2, 'METAL', 'metal', 'METAL', '2022-09-10 01:02:18', '2022-09-10 01:02:18'),
(13, 2, 'PLASTIC', 'plastic', 'PLASTIC', '2022-09-10 01:02:29', '2022-09-10 01:02:29'),
(14, 2, 'RIM LESS', 'rim-less', 'RIM LESS', '2022-09-10 01:02:42', '2022-09-10 01:02:42'),
(15, 2, 'WOODEN', 'wooden', 'WOODEN', '2022-09-10 01:02:51', '2022-09-10 01:02:51');

-- --------------------------------------------------------

--
-- Table structure for table `frame_prescriptions`
--

CREATE TABLE `frame_prescriptions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `power_id` bigint(20) UNSIGNED NOT NULL,
  `prescription_id` bigint(20) UNSIGNED NOT NULL,
  `stock_id` bigint(20) UNSIGNED DEFAULT NULL,
  `frame_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receipt_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `workshop_id` bigint(20) UNSIGNED NOT NULL,
  `remarks` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `frame_shapes`
--

CREATE TABLE `frame_shapes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `shape` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `frame_shapes`
--

INSERT INTO `frame_shapes` (`id`, `organization_id`, `shape`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(10, 2, 'AVIATORS', 'aviators-1662783115', 'AVIATORS', '2022-09-10 01:11:06', '2022-09-10 01:11:55'),
(11, 2, 'CAT EYESWRAP', 'cat-eyeswrap-1662783128', 'CAT EYESWRAP', '2022-09-10 01:12:08', '2022-09-10 01:12:08'),
(12, 2, 'FIFASHION', 'fifashion-1662783138', 'FIFASHION', '2022-09-10 01:12:18', '2022-09-10 01:12:18'),
(13, 2, 'GEOMETRIC', 'geometric-1662783150', 'GEOMETRIC', '2022-09-10 01:12:30', '2022-09-10 01:12:30'),
(14, 2, 'OVAL', 'oval-1662783160', 'OVAL', '2022-09-10 01:12:40', '2022-09-10 01:12:40'),
(15, 2, 'RECTANGLE', 'rectangle-1662783169', 'RECTANGLE', '2022-09-10 01:12:49', '2022-09-10 01:12:49'),
(16, 2, 'ROUND', 'round-1662783181', 'ROUND', '2022-09-10 01:13:01', '2022-09-10 01:13:01'),
(17, 2, 'SQUARE', 'square-1662783191', 'SQUARE', '2022-09-10 01:13:11', '2022-09-10 01:13:11'),
(18, 2, 'WAYFARER', 'wayfarer-1662783202', 'WAYFARER', '2022-09-10 01:13:22', '2022-09-10 01:13:22');

-- --------------------------------------------------------

--
-- Table structure for table `frame_sizes`
--

CREATE TABLE `frame_sizes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `frame_sizes`
--

INSERT INTO `frame_sizes` (`id`, `organization_id`, `size`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(1, 1, '58-29-48', '58-29-48', '58-29-48', '2022-09-03 02:01:59', '2022-09-03 02:01:59'),
(2, 1, '56-25-48', '56-25-48', '56-25-48', '2022-09-03 02:02:09', '2022-09-03 02:02:09'),
(3, 1, '53-18-142', '53-18-142', '53-18-142', '2022-09-03 02:02:20', '2022-09-03 02:02:20'),
(4, 2, '53-18-142', '53-18-142-1662782941', '53-18-142', '2022-09-10 01:09:01', '2022-09-10 01:09:01'),
(5, 2, '56-25-48', '56-25-48-1662782954', '56-25-48', '2022-09-10 01:09:14', '2022-09-10 01:09:14'),
(6, 2, '58-29-48', '58-29-48-1662782964', '58-29-48', '2022-09-10 01:09:24', '2022-09-10 01:09:24');

-- --------------------------------------------------------

--
-- Table structure for table `frame_stocks`
--

CREATE TABLE `frame_stocks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `clinic_id` bigint(20) UNSIGNED NOT NULL,
  `frame_id` bigint(20) UNSIGNED NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color_id` bigint(20) UNSIGNED NOT NULL,
  `shape_id` bigint(20) UNSIGNED NOT NULL,
  `opening_stock` int(11) NOT NULL,
  `purchase_stock` int(11) NOT NULL,
  `total_stock` int(11) NOT NULL,
  `sold_stock` int(11) NOT NULL,
  `closing_stock` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `supplier_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `remarks` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `frame_stocks`
--

INSERT INTO `frame_stocks` (`id`, `clinic_id`, `frame_id`, `gender`, `color_id`, `shape_id`, `opening_stock`, `purchase_stock`, `total_stock`, `sold_stock`, `closing_stock`, `price`, `supplier_price`, `remarks`, `created_at`, `updated_at`) VALUES
(2, 4, 2, 'Unisex', 7, 10, 20, 0, 20, 0, 20, '2500.00', '1500.00', NULL, '2022-09-10 09:55:54', '2022-09-10 09:55:54'),
(3, 4, 3, 'Unisex', 8, 11, 10, 0, 10, 0, 10, '1200.00', '800.00', NULL, '2022-09-10 09:58:52', '2022-09-10 09:58:52'),
(4, 4, 5, 'Male', 7, 10, 10, 0, 10, 0, 10, '200.00', '150.00', NULL, '2022-11-02 03:45:33', '2022-11-02 03:45:33'),
(5, 3, 13, 'Male', 7, 10, 100, 0, 100, 0, 100, '4500.00', '3500.00', NULL, '2022-11-05 07:19:48', '2022-11-05 07:19:48');

-- --------------------------------------------------------

--
-- Table structure for table `frame_types`
--

CREATE TABLE `frame_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `frame_types`
--

INSERT INTO `frame_types` (`id`, `organization_id`, `title`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(6, 2, 'Accusantium asperior', 'accusantium-asperior', 'Accusantium asperior', '2022-09-10 00:59:45', '2022-09-10 00:59:45'),
(7, 2, 'At ut ea delectus n', 'at-ut-ea-delectus-n', 'At ut ea delectus n', '2022-09-10 00:59:54', '2022-09-10 00:59:54'),
(8, 2, 'DESIGNER FULL RIM', 'designer-full-rim', 'DESIGNER FULL RIM', '2022-09-10 01:00:05', '2022-09-10 01:00:05'),
(9, 2, 'DESIGNER PLASTIC', 'designer-plastic', 'DESIGNER PLASTIC', '2022-09-10 01:00:38', '2022-09-10 01:00:38'),
(10, 2, 'Molestias sed volupt', 'molestias-sed-volupt', 'Molestias sed volupt', '2022-09-10 01:00:48', '2022-09-10 01:00:48'),
(11, 2, 'OWN FRAMES', 'own-frames', 'OWN FRAMES', '2022-09-10 01:01:40', '2022-09-10 01:01:40'),
(12, 2, 'RIM LESS FRAME', 'rim-less-frame', 'RIM LESS FRAME', '2022-09-10 01:01:48', '2022-09-10 01:01:48');

-- --------------------------------------------------------

--
-- Table structure for table `insurances`
--

CREATE TABLE `insurances` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `insurances`
--

INSERT INTO `insurances` (`id`, `organization_id`, `title`, `phone`, `email`, `address`, `description`, `created_at`, `updated_at`) VALUES
(3, 2, 'NHIF', '0800 720 601', 'info@nhif.or.ke', 'P.O. BOX 30443-00100, Nairobi, Kenya', NULL, '2022-09-10 00:36:25', '2022-09-10 00:36:25'),
(4, 2, 'Jubilee Insurance', '254709949000', 'info@jubileekenya.com', 'P. O. Box 30376 - 00100 Nairobi, Kenya', NULL, '2022-09-10 00:40:02', '2022-09-10 00:40:02');

-- --------------------------------------------------------

--
-- Table structure for table `lens_materials`
--

CREATE TABLE `lens_materials` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lens_materials`
--

INSERT INTO `lens_materials` (`id`, `organization_id`, `title`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(14, 2, 'DAILY USAGE-DISPOSABLE CONTACT LENSES', 'daily-usage-disposable-contact-lenses', 'DAILY USAGE-DISPOSABLE CONTACT LENSES', '2022-09-10 00:52:55', '2022-09-10 00:52:55'),
(15, 2, 'Glass', 'glass', 'Glass', '2022-09-10 00:53:08', '2022-09-10 00:53:08'),
(16, 2, 'GLASS CLEAR', 'glass-clear', 'GLASS CLEAR', '2022-09-10 00:53:19', '2022-09-10 00:53:19'),
(17, 2, 'GLASS CLEAR BLUE CUT', 'glass-clear-blue-cut', 'GLASS CLEAR BLUE CUT', '2022-09-10 00:53:34', '2022-09-10 00:53:34'),
(18, 2, 'GLASS CLEAR BLUE CUT', 'glass-clear-blue-cut', 'GLASS CLEAR BLUE CUT', '2022-09-10 00:53:46', '2022-09-10 00:53:46'),
(19, 2, 'GLASS CLEAR HMC', 'glass-clear-hmc', 'GLASS CLEAR HMC', '2022-09-10 00:54:13', '2022-09-10 00:54:13'),
(20, 2, 'GLASS PHOTO', 'glass-photo', 'GLASS PHOTO', '2022-09-10 00:54:25', '2022-09-10 00:54:25'),
(21, 2, 'GLASS PHOTO HMC', 'glass-photo-hmc', 'GLASS PHOTO HMC', '2022-09-10 00:54:35', '2022-09-10 00:54:35'),
(22, 2, 'HALF YEARLY-CONTACT LENSES', 'half-yearly-contact-lenses', 'HALF YEARLY-CONTACT LENSES', '2022-09-10 00:54:44', '2022-09-10 00:54:44'),
(23, 2, 'MONTHLY-CONTACT LENSES', 'monthly-contact-lenses', 'MONTHLY-CONTACT LENSES', '2022-09-10 00:54:56', '2022-09-10 00:54:56'),
(24, 2, 'Plastic', 'plastic', 'Plastic', '2022-09-10 00:55:08', '2022-09-10 00:55:08'),
(25, 2, 'PLASTIC CLEAR', 'plastic-clear', 'PLASTIC CLEAR', '2022-09-10 00:55:18', '2022-09-10 00:55:18'),
(26, 2, 'PLASTIC CLEAR BLUE CUT', 'plastic-clear-blue-cut', 'PLASTIC CLEAR BLUE CUT', '2022-09-10 00:55:30', '2022-09-10 00:55:30'),
(27, 2, 'PLASTIC CLEAR HMC', 'plastic-clear-hmc', 'PLASTIC CLEAR HMC', '2022-09-10 00:55:40', '2022-09-10 00:55:40'),
(28, 2, 'PLASTIC PHOTO', 'plastic-photo', 'PLASTIC PHOTO', '2022-09-10 00:55:50', '2022-09-10 00:55:50'),
(29, 2, 'PLASTIC PHOTO BLUE CUT', 'plastic-photo-blue-cut', 'PLASTIC PHOTO BLUE CUT', '2022-09-10 00:56:01', '2022-09-10 00:56:01'),
(30, 2, 'PLASTIC PHOTO HMC', 'plastic-photo-hmc', 'PLASTIC PHOTO HMC', '2022-09-10 00:56:14', '2022-09-10 00:56:14'),
(31, 2, 'PLASTIC READING GLASSES', 'plastic-reading-glasses', 'PLASTIC READING GLASSES', '2022-09-10 00:56:26', '2022-09-10 00:56:26'),
(32, 2, 'YEARLY CONTACT LENSES', 'yearly-contact-lenses', 'YEARLY CONTACT LENSES', '2022-09-10 00:56:37', '2022-09-10 00:56:37');

-- --------------------------------------------------------

--
-- Table structure for table `lens_powers`
--

CREATE TABLE `lens_powers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `patient_id` bigint(20) UNSIGNED NOT NULL,
  `appointment_id` bigint(20) UNSIGNED NOT NULL,
  `schedule_id` bigint(20) UNSIGNED NOT NULL,
  `diagnoisis_id` bigint(20) UNSIGNED NOT NULL,
  `right_sphere` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `right_cylinder` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `right_axis` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `right_add` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `left_sphere` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `left_cylinder` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `left_axis` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `left_add` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lens_prescriptions`
--

CREATE TABLE `lens_prescriptions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `power_id` bigint(20) UNSIGNED NOT NULL,
  `type_id` bigint(20) UNSIGNED NOT NULL,
  `material_id` bigint(20) UNSIGNED NOT NULL,
  `index` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tint` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `diameter` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `focal_height` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lens_types`
--

CREATE TABLE `lens_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lens_types`
--

INSERT INTO `lens_types` (`id`, `organization_id`, `type`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(6, 2, 'BI-FOCAL-PHOTO PLASTIC HMC', 'bi-focal-photo-plastic-hmc', 'BI-FOCAL-PHOTO PLASTIC HMC', '2022-09-10 00:43:28', '2022-09-10 00:43:28'),
(7, 2, 'BI FOCAL-MIXED COMPOUND', 'bi-focal-mixed-compound', 'BI FOCAL-MIXED COMPOUND', '2022-09-10 00:43:43', '2022-09-10 00:43:43'),
(8, 2, 'HALF YEARLY-CONTACT LENSES', 'half-yearly-contact-lenses', 'HALF YEARLY-CONTACT LENSES', '2022-09-10 00:43:55', '2022-09-10 00:43:55'),
(9, 2, 'MONTHLY-CONTACT LENSES', 'monthly-contact-lenses', 'MONTHLY-CONTACT LENSES', '2022-09-10 00:44:04', '2022-09-10 00:44:04'),
(10, 2, 'PROGRESSIVE', 'progressive', 'PROGRESSIVE', '2022-09-10 00:44:15', '2022-09-10 00:44:15'),
(11, 2, 'PROGRESSIVE-MIXED COMPOUND', 'progressive-mixed-compound', 'PROGRESSIVE-MIXED COMPOUND', '2022-09-10 00:44:28', '2022-09-10 00:44:28'),
(12, 2, 'READING GLASSES', 'reading-glasses', 'READING GLASSES', '2022-09-10 00:44:40', '2022-09-10 00:44:40'),
(13, 2, 'SINGLE DAY-CONTACT LENSES', 'single-day-contact-lenses', 'SINGLE DAY-CONTACT LENSES', '2022-09-10 00:44:51', '2022-09-10 00:44:51'),
(14, 2, 'SINGLE VISION', 'single-vision', 'SINGLE VISION', '2022-09-10 00:45:02', '2022-09-10 00:45:02'),
(15, 2, 'SINGLE VISION-MIXED COMPOUND', 'single-vision-mixed-compound', 'SINGLE VISION-MIXED COMPOUND', '2022-09-10 00:45:12', '2022-09-10 00:45:12'),
(16, 2, 'YEARLY-CONTACT LENSES', 'yearly-contact-lenses', 'YEARLY-CONTACT LENSES', '2022-09-10 00:46:48', '2022-09-10 00:46:48');

-- --------------------------------------------------------

--
-- Table structure for table `medicines`
--

CREATE TABLE `medicines` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `patient_id` bigint(20) UNSIGNED NOT NULL,
  `schedule_id` bigint(20) UNSIGNED NOT NULL,
  `diagnosis_id` bigint(20) UNSIGNED NOT NULL,
  `medicine` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dose` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_100000_create_password_resets_table', 1),
(2, '2019_08_19_000000_create_failed_jobs_table', 1),
(3, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(4, '2022_07_01_090313_create_admins_table', 1),
(5, '2022_07_04_101754_create_organizations_table', 1),
(6, '2022_07_07_054250_create_clinics_table', 1),
(7, '2022_07_09_094639_create_patients_table', 1),
(8, '2022_07_15_054312_create_statuses_table', 1),
(9, '2022_07_18_132727_create_client_types_table', 1),
(10, '2022_07_18_142327_create_insurances_table', 1),
(11, '2022_07_19_151941_laratrust_setup_tables', 1),
(12, '2022_07_20_095806_create_users_table', 1),
(13, '2022_07_21_100227_create_appointments_table', 1),
(14, '2022_07_21_100651_create_payment_details_table', 1),
(15, '2022_07_21_103850_create_doctor_schedules_table', 1),
(16, '2022_07_22_111443_create_diagnoses_table', 1),
(17, '2022_07_24_135231_create_lens_types_table', 1),
(18, '2022_07_25_010708_create_lens_materials_table', 1),
(19, '2022_07_25_030755_create_lens_powers_table', 1),
(20, '2022_07_25_102854_create_lens_prescriptions_table', 1),
(21, '2022_07_25_132050_create_workshops_table', 1),
(22, '2022_07_25_150202_create_frame_prescriptions_table', 1),
(23, '2022_07_26_095548_add_initials_to_clinics_table', 1),
(24, '2022_07_26_101820_create_medicines_table', 1),
(25, '2022_07_26_115806_create_procedures_table', 1),
(26, '2022_07_26_150013_create_payment_bills_table', 1),
(27, '2022_07_29_085139_create_billings_table', 1),
(28, '2022_08_01_134225_create_orders_table', 1),
(29, '2022_08_02_124240_create_order_tracks_table', 1),
(30, '2022_08_03_141004_create_asset_types_table', 1),
(31, '2022_08_04_025300_create_asset_conditions_table', 1),
(32, '2022_08_04_062149_create_assets_table', 1),
(33, '2022_08_04_235235_create_asset_transfers_table', 1),
(34, '2022_08_05_102242_create_frame_types_table', 1),
(35, '2022_08_05_110112_create_frame_materials_table', 1),
(36, '2022_08_07_031930_create_frame_brands_table', 1),
(37, '2022_08_07_040544_create_frame_sizes_table', 1),
(38, '2022_08_07_190807_create_frame_colors_table', 1),
(39, '2022_08_07_195112_create_frame_shapes_table', 1),
(40, '2022_08_08_090300_create_frames_table', 1),
(41, '2022_08_08_120758_create_frame_stocks_table', 1),
(42, '2022_08_10_004757_add_stock_id_to_frame_prescriptions_table', 1),
(43, '2022_08_10_011800_create_sun_glasses_table', 1),
(44, '2022_08_10_180105_create_contact_lens_table', 1),
(45, '2022_08_11_131913_create_colors_table', 1),
(46, '2022_08_12_081334_create_shapes_table', 1),
(47, '2022_08_12_083301_create_sizes_table', 1),
(48, '2022_08_12_083925_create_sun_glass_stocks_table', 1),
(49, '2022_08_14_011638_create_remittances_table', 1),
(50, '2022_08_15_052008_add_user_id_to_patients_table', 1),
(51, '2022_08_17_110327_add_remittance_balance_to_payment_bills_table', 1),
(52, '2022_08_23_042122_create_reports_table', 1),
(53, '2022_08_26_023359_add_id_number_to_patients_table', 1),
(54, '2022_09_03_040102_add_report_id_to_appointments_table', 2),
(55, '2022_09_03_194256_add_bill_closed_date_to_reports_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `clinic_id` bigint(20) UNSIGNED NOT NULL,
  `patient_id` bigint(20) UNSIGNED NOT NULL,
  `appointment_id` bigint(20) UNSIGNED NOT NULL,
  `schedule_id` bigint(20) UNSIGNED NOT NULL,
  `payment_bill_id` bigint(20) UNSIGNED NOT NULL,
  `workshop_id` bigint(20) UNSIGNED NOT NULL,
  `lens_power_id` bigint(20) UNSIGNED NOT NULL,
  `lens_prescription_id` bigint(20) UNSIGNED NOT NULL,
  `frame_prescription_id` bigint(20) UNSIGNED NOT NULL,
  `order_date` date DEFAULT NULL,
  `receipt_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `closed_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_tracks`
--

CREATE TABLE `order_tracks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `workshop_id` bigint(20) UNSIGNED NOT NULL,
  `track_date` date NOT NULL,
  `track_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `organizations`
--

CREATE TABLE `organizations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `admin_id` bigint(20) UNSIGNED NOT NULL,
  `organization` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tagline` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `organizations`
--

INSERT INTO `organizations` (`id`, `admin_id`, `organization`, `tagline`, `logo`, `phone`, `email`, `address`, `location`, `website`, `profile`, `created_at`, `updated_at`) VALUES
(2, 2, 'Sais Eye Clinic', 'Sais Eye Clinic', 'noimage.png', '0701666667', 'info@saiseyeclinics.com', NULL, 'Nairobi', NULL, NULL, '2022-09-10 00:12:14', '2022-09-10 00:12:14');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `clinic_id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `next_of_kin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `next_of_kin_contact` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_bills`
--

CREATE TABLE `payment_bills` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `clinic_id` bigint(20) UNSIGNED NOT NULL,
  `patient_id` bigint(20) UNSIGNED NOT NULL,
  `appointment_id` bigint(20) UNSIGNED NOT NULL,
  `schedule_id` bigint(20) UNSIGNED NOT NULL,
  `payment_details_id` bigint(20) UNSIGNED NOT NULL,
  `open_date` date NOT NULL,
  `consultation_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `consultation_receipt_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lpo_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approval_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approval_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bill_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `close_date` date DEFAULT NULL,
  `claimed_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `agreed_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `balance` decimal(10,2) NOT NULL DEFAULT 0.00,
  `remittance_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `remittance_balance` decimal(10,2) NOT NULL DEFAULT 0.00,
  `remarks` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `terms` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_details`
--

CREATE TABLE `payment_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `clinic_id` bigint(20) UNSIGNED NOT NULL,
  `patient_id` bigint(20) UNSIGNED NOT NULL,
  `appointment_id` bigint(20) UNSIGNED NOT NULL,
  `client_type_id` bigint(20) UNSIGNED NOT NULL,
  `insurance_id` bigint(20) UNSIGNED DEFAULT NULL,
  `scheme` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `principal` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workplace` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `principal_workplace` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'users-create', 'Create Users', 'Create Users', '2022-09-03 02:14:08', '2022-09-03 02:14:08'),
(2, 'users-read', 'Read Users', 'Read Users', '2022-09-03 02:14:08', '2022-09-03 02:14:08'),
(3, 'users-update', 'Update Users', 'Update Users', '2022-09-03 02:14:08', '2022-09-03 02:14:08'),
(4, 'users-delete', 'Delete Users', 'Delete Users', '2022-09-03 02:14:08', '2022-09-03 02:14:08'),
(5, 'payments-create', 'Create Payments', 'Create Payments', '2022-09-03 02:14:08', '2022-09-03 02:14:08'),
(6, 'payments-read', 'Read Payments', 'Read Payments', '2022-09-03 02:14:08', '2022-09-03 02:14:08'),
(7, 'payments-update', 'Update Payments', 'Update Payments', '2022-09-03 02:14:08', '2022-09-03 02:14:08'),
(8, 'payments-delete', 'Delete Payments', 'Delete Payments', '2022-09-03 02:14:08', '2022-09-03 02:14:08'),
(9, 'profile-read', 'Read Profile', 'Read Profile', '2022-09-03 02:14:08', '2022-09-03 02:14:08'),
(10, 'profile-update', 'Update Profile', 'Update Profile', '2022-09-03 02:14:08', '2022-09-03 02:14:08'),
(11, 'module_1_name-create', 'Create Module_1_name', 'Create Module_1_name', '2022-09-03 02:14:08', '2022-09-03 02:14:08'),
(12, 'module_1_name-read', 'Read Module_1_name', 'Read Module_1_name', '2022-09-03 02:14:08', '2022-09-03 02:14:08'),
(13, 'module_1_name-update', 'Update Module_1_name', 'Update Module_1_name', '2022-09-03 02:14:08', '2022-09-03 02:14:08'),
(14, 'module_1_name-delete', 'Delete Module_1_name', 'Delete Module_1_name', '2022-09-03 02:14:08', '2022-09-03 02:14:08');

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE `permission_role` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_role`
--

INSERT INTO `permission_role` (`permission_id`, `role_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(2, 1),
(2, 2),
(2, 3),
(3, 1),
(3, 2),
(3, 3),
(4, 1),
(4, 2),
(4, 3),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(9, 2),
(9, 3),
(9, 4),
(10, 1),
(10, 2),
(10, 3),
(10, 4),
(11, 5),
(12, 5),
(13, 5),
(14, 5);

-- --------------------------------------------------------

--
-- Table structure for table `permission_user`
--

CREATE TABLE `permission_user` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `user_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `procedures`
--

CREATE TABLE `procedures` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `schedule_id` bigint(20) UNSIGNED NOT NULL,
  `diagnosis_id` bigint(20) UNSIGNED NOT NULL,
  `procedure` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `remittances`
--

CREATE TABLE `remittances` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `clinic_id` bigint(20) UNSIGNED NOT NULL,
  `bill_id` bigint(20) UNSIGNED NOT NULL,
  `bill_invoice` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `paid` decimal(10,2) NOT NULL DEFAULT 0.00,
  `balance` decimal(10,2) NOT NULL DEFAULT 0.00,
  `remittance_date` date DEFAULT NULL,
  `closed_date` date DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'OPEN',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `clinic_id` bigint(20) UNSIGNED DEFAULT NULL,
  `patient_id` bigint(20) UNSIGNED DEFAULT NULL,
  `appointment_id` bigint(20) UNSIGNED DEFAULT NULL,
  `payment_details_id` bigint(20) UNSIGNED DEFAULT NULL,
  `schedule_id` bigint(20) UNSIGNED DEFAULT NULL,
  `diagnosis_id` bigint(20) UNSIGNED DEFAULT NULL,
  `power_id` bigint(20) UNSIGNED DEFAULT NULL,
  `lens_prescription_id` bigint(20) UNSIGNED DEFAULT NULL,
  `frame_prescription_id` bigint(20) UNSIGNED DEFAULT NULL,
  `bill_id` bigint(20) UNSIGNED DEFAULT NULL,
  `order_id` bigint(20) UNSIGNED DEFAULT NULL,
  `appointment_date` date DEFAULT NULL,
  `bill_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bill_closed_date` date DEFAULT NULL,
  `consultation_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `claimed_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `agreed_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `balance` decimal(10,2) NOT NULL DEFAULT 0.00,
  `order_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Admin', 'Admin', '2022-09-03 02:14:07', '2022-09-03 02:14:07'),
(2, 'optometrist', 'Optometrist', 'Optometrist', '2022-09-03 02:14:08', '2022-09-03 02:14:08'),
(3, 'doctor', 'Doctor', 'Doctor', '2022-09-03 02:14:08', '2022-09-03 02:14:08'),
(4, 'user', 'User', 'User', '2022-09-03 02:14:08', '2022-09-03 02:14:08'),
(5, 'role_name', 'Role Name', 'Role Name', '2022-09-03 02:14:08', '2022-09-03 02:14:08');

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `user_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`role_id`, `user_id`, `user_type`) VALUES
(3, 3, 'App\\Models\\User');

-- --------------------------------------------------------

--
-- Table structure for table `shapes`
--

CREATE TABLE `shapes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `shape` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sizes`
--

CREATE TABLE `sizes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sizes`
--

INSERT INTO `sizes` (`id`, `organization_id`, `size`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(4, 2, 'Large', 'large', 'Large', '2022-09-10 01:18:28', '2022-09-10 01:18:28'),
(5, 2, 'Medium', 'medium', 'Medium', '2022-09-10 01:18:40', '2022-09-10 01:18:40'),
(6, 2, 'Small', 'small', 'Small', '2022-09-10 01:18:51', '2022-09-10 01:18:51');

-- --------------------------------------------------------

--
-- Table structure for table `statuses`
--

CREATE TABLE `statuses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sun_glasses`
--

CREATE TABLE `sun_glasses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `clinic_id` bigint(20) UNSIGNED NOT NULL,
  `brand_id` bigint(20) UNSIGNED DEFAULT NULL,
  `item_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sun_glass_stocks`
--

CREATE TABLE `sun_glass_stocks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `clinic_id` bigint(20) UNSIGNED NOT NULL,
  `glass_id` bigint(20) UNSIGNED NOT NULL,
  `color_id` bigint(20) UNSIGNED NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shape_id` bigint(20) UNSIGNED NOT NULL,
  `size_id` bigint(20) UNSIGNED NOT NULL,
  `opening_stock` bigint(20) UNSIGNED NOT NULL,
  `purchase_stock` bigint(20) UNSIGNED NOT NULL,
  `total_stock` bigint(20) UNSIGNED NOT NULL,
  `sold_stock` bigint(20) UNSIGNED NOT NULL,
  `closing_stock` bigint(20) UNSIGNED NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `supplier_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `remarks` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `clinic_id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `workshops`
--

CREATE TABLE `workshops` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_phone_unique` (`phone`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `appointments_clinic_id_foreign` (`clinic_id`),
  ADD KEY `appointments_patient_id_foreign` (`patient_id`),
  ADD KEY `appointments_user_id_foreign` (`user_id`),
  ADD KEY `appointments_report_id_foreign` (`report_id`);

--
-- Indexes for table `assets`
--
ALTER TABLE `assets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assets_clinic_id_foreign` (`clinic_id`),
  ADD KEY `assets_type_id_foreign` (`type_id`),
  ADD KEY `assets_condition_id_foreign` (`condition_id`);

--
-- Indexes for table `asset_conditions`
--
ALTER TABLE `asset_conditions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `asset_conditions_organization_id_foreign` (`organization_id`);

--
-- Indexes for table `asset_transfers`
--
ALTER TABLE `asset_transfers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `asset_transfers_organization_id_foreign` (`organization_id`),
  ADD KEY `asset_transfers_asset_id_foreign` (`asset_id`),
  ADD KEY `asset_transfers_type_id_foreign` (`type_id`),
  ADD KEY `asset_transfers_condition_id_foreign` (`condition_id`);

--
-- Indexes for table `asset_types`
--
ALTER TABLE `asset_types`
  ADD PRIMARY KEY (`id`),
  ADD KEY `asset_types_organization_id_foreign` (`organization_id`);

--
-- Indexes for table `billings`
--
ALTER TABLE `billings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `billings_payment_bill_id_foreign` (`payment_bill_id`);

--
-- Indexes for table `client_types`
--
ALTER TABLE `client_types`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_types_organization_id_foreign` (`organization_id`);

--
-- Indexes for table `clinics`
--
ALTER TABLE `clinics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `clinics_organization_id_foreign` (`organization_id`);

--
-- Indexes for table `colors`
--
ALTER TABLE `colors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `colors_organization_id_foreign` (`organization_id`);

--
-- Indexes for table `contact_lens`
--
ALTER TABLE `contact_lens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `contact_lens_item_code_unique` (`item_code`),
  ADD KEY `contact_lens_clinic_id_foreign` (`clinic_id`),
  ADD KEY `contact_lens_type_id_foreign` (`type_id`),
  ADD KEY `contact_lens_material_id_foreign` (`material_id`);

--
-- Indexes for table `diagnoses`
--
ALTER TABLE `diagnoses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `diagnoses_clinic_id_foreign` (`clinic_id`),
  ADD KEY `diagnoses_user_id_foreign` (`user_id`),
  ADD KEY `diagnoses_patient_id_foreign` (`patient_id`),
  ADD KEY `diagnoses_appointment_id_foreign` (`appointment_id`),
  ADD KEY `diagnoses_schedule_id_foreign` (`schedule_id`);

--
-- Indexes for table `doctor_schedules`
--
ALTER TABLE `doctor_schedules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `doctor_schedules_clinic_id_foreign` (`clinic_id`),
  ADD KEY `doctor_schedules_user_id_foreign` (`user_id`),
  ADD KEY `doctor_schedules_patient_id_foreign` (`patient_id`),
  ADD KEY `doctor_schedules_appointment_id_foreign` (`appointment_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `frames`
--
ALTER TABLE `frames`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `frames_code_unique` (`code`),
  ADD KEY `frames_clinic_id_foreign` (`clinic_id`),
  ADD KEY `frames_brand_id_foreign` (`brand_id`),
  ADD KEY `frames_type_id_foreign` (`type_id`),
  ADD KEY `frames_size_id_foreign` (`size_id`),
  ADD KEY `frames_material_id_foreign` (`material_id`);

--
-- Indexes for table `frame_brands`
--
ALTER TABLE `frame_brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `frame_brands_slug_unique` (`slug`);

--
-- Indexes for table `frame_colors`
--
ALTER TABLE `frame_colors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `frame_colors_organization_id_foreign` (`organization_id`);

--
-- Indexes for table `frame_materials`
--
ALTER TABLE `frame_materials`
  ADD PRIMARY KEY (`id`),
  ADD KEY `frame_materials_organization_id_foreign` (`organization_id`);

--
-- Indexes for table `frame_prescriptions`
--
ALTER TABLE `frame_prescriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `frame_prescriptions_power_id_foreign` (`power_id`),
  ADD KEY `frame_prescriptions_prescription_id_foreign` (`prescription_id`),
  ADD KEY `frame_prescriptions_workshop_id_foreign` (`workshop_id`),
  ADD KEY `frame_prescriptions_stock_id_foreign` (`stock_id`);

--
-- Indexes for table `frame_shapes`
--
ALTER TABLE `frame_shapes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `frame_shapes_organization_id_foreign` (`organization_id`);

--
-- Indexes for table `frame_sizes`
--
ALTER TABLE `frame_sizes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `frame_stocks`
--
ALTER TABLE `frame_stocks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `frame_stocks_clinic_id_foreign` (`clinic_id`),
  ADD KEY `frame_stocks_frame_id_foreign` (`frame_id`),
  ADD KEY `frame_stocks_color_id_foreign` (`color_id`),
  ADD KEY `frame_stocks_shape_id_foreign` (`shape_id`);

--
-- Indexes for table `frame_types`
--
ALTER TABLE `frame_types`
  ADD PRIMARY KEY (`id`),
  ADD KEY `frame_types_organization_id_foreign` (`organization_id`);

--
-- Indexes for table `insurances`
--
ALTER TABLE `insurances`
  ADD PRIMARY KEY (`id`),
  ADD KEY `insurances_organization_id_foreign` (`organization_id`);

--
-- Indexes for table `lens_materials`
--
ALTER TABLE `lens_materials`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lens_materials_organization_id_foreign` (`organization_id`);

--
-- Indexes for table `lens_powers`
--
ALTER TABLE `lens_powers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lens_powers_patient_id_foreign` (`patient_id`),
  ADD KEY `lens_powers_appointment_id_foreign` (`appointment_id`),
  ADD KEY `lens_powers_schedule_id_foreign` (`schedule_id`),
  ADD KEY `lens_powers_diagnoisis_id_foreign` (`diagnoisis_id`);

--
-- Indexes for table `lens_prescriptions`
--
ALTER TABLE `lens_prescriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lens_prescriptions_power_id_foreign` (`power_id`),
  ADD KEY `lens_prescriptions_type_id_foreign` (`type_id`),
  ADD KEY `lens_prescriptions_material_id_foreign` (`material_id`);

--
-- Indexes for table `lens_types`
--
ALTER TABLE `lens_types`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lens_types_organization_id_foreign` (`organization_id`);

--
-- Indexes for table `medicines`
--
ALTER TABLE `medicines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `medicines_patient_id_foreign` (`patient_id`),
  ADD KEY `medicines_schedule_id_foreign` (`schedule_id`),
  ADD KEY `medicines_diagnosis_id_foreign` (`diagnosis_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_clinic_id_foreign` (`clinic_id`),
  ADD KEY `orders_patient_id_foreign` (`patient_id`),
  ADD KEY `orders_appointment_id_foreign` (`appointment_id`),
  ADD KEY `orders_schedule_id_foreign` (`schedule_id`),
  ADD KEY `orders_payment_bill_id_foreign` (`payment_bill_id`),
  ADD KEY `orders_workshop_id_foreign` (`workshop_id`),
  ADD KEY `orders_lens_power_id_foreign` (`lens_power_id`),
  ADD KEY `orders_lens_prescription_id_foreign` (`lens_prescription_id`),
  ADD KEY `orders_frame_prescription_id_foreign` (`frame_prescription_id`);

--
-- Indexes for table `order_tracks`
--
ALTER TABLE `order_tracks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_tracks_order_id_foreign` (`order_id`),
  ADD KEY `order_tracks_user_id_foreign` (`user_id`),
  ADD KEY `order_tracks_workshop_id_foreign` (`workshop_id`);

--
-- Indexes for table `organizations`
--
ALTER TABLE `organizations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `organizations_admin_id_foreign` (`admin_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `patients_id_number_unique` (`id_number`),
  ADD KEY `patients_clinic_id_foreign` (`clinic_id`),
  ADD KEY `patients_user_id_foreign` (`user_id`);

--
-- Indexes for table `payment_bills`
--
ALTER TABLE `payment_bills`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payment_bills_clinic_id_foreign` (`clinic_id`),
  ADD KEY `payment_bills_patient_id_foreign` (`patient_id`),
  ADD KEY `payment_bills_appointment_id_foreign` (`appointment_id`),
  ADD KEY `payment_bills_schedule_id_foreign` (`schedule_id`),
  ADD KEY `payment_bills_payment_details_id_foreign` (`payment_details_id`);

--
-- Indexes for table `payment_details`
--
ALTER TABLE `payment_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payment_details_clinic_id_foreign` (`clinic_id`),
  ADD KEY `payment_details_patient_id_foreign` (`patient_id`),
  ADD KEY `payment_details_appointment_id_foreign` (`appointment_id`),
  ADD KEY `payment_details_client_type_id_foreign` (`client_type_id`),
  ADD KEY `payment_details_insurance_id_foreign` (`insurance_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_unique` (`name`);

--
-- Indexes for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `permission_role_role_id_foreign` (`role_id`);

--
-- Indexes for table `permission_user`
--
ALTER TABLE `permission_user`
  ADD PRIMARY KEY (`user_id`,`permission_id`,`user_type`),
  ADD KEY `permission_user_permission_id_foreign` (`permission_id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `procedures`
--
ALTER TABLE `procedures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `procedures_schedule_id_foreign` (`schedule_id`),
  ADD KEY `procedures_diagnosis_id_foreign` (`diagnosis_id`);

--
-- Indexes for table `remittances`
--
ALTER TABLE `remittances`
  ADD PRIMARY KEY (`id`),
  ADD KEY `remittances_clinic_id_foreign` (`clinic_id`),
  ADD KEY `remittances_bill_id_foreign` (`bill_id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reports_clinic_id_foreign` (`clinic_id`),
  ADD KEY `reports_patient_id_foreign` (`patient_id`),
  ADD KEY `reports_appointment_id_foreign` (`appointment_id`),
  ADD KEY `reports_payment_details_id_foreign` (`payment_details_id`),
  ADD KEY `reports_schedule_id_foreign` (`schedule_id`),
  ADD KEY `reports_diagnosis_id_foreign` (`diagnosis_id`),
  ADD KEY `reports_power_id_foreign` (`power_id`),
  ADD KEY `reports_lens_prescription_id_foreign` (`lens_prescription_id`),
  ADD KEY `reports_frame_prescription_id_foreign` (`frame_prescription_id`),
  ADD KEY `reports_bill_id_foreign` (`bill_id`),
  ADD KEY `reports_order_id_foreign` (`order_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`user_id`,`role_id`,`user_type`),
  ADD KEY `role_user_role_id_foreign` (`role_id`);

--
-- Indexes for table `shapes`
--
ALTER TABLE `shapes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shapes_organization_id_foreign` (`organization_id`);

--
-- Indexes for table `sizes`
--
ALTER TABLE `sizes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sizes_organization_id_foreign` (`organization_id`);

--
-- Indexes for table `statuses`
--
ALTER TABLE `statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sun_glasses`
--
ALTER TABLE `sun_glasses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sun_glasses_item_code_unique` (`item_code`);

--
-- Indexes for table `sun_glass_stocks`
--
ALTER TABLE `sun_glass_stocks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sun_glass_stocks_clinic_id_foreign` (`clinic_id`),
  ADD KEY `sun_glass_stocks_glass_id_foreign` (`glass_id`),
  ADD KEY `sun_glass_stocks_color_id_foreign` (`color_id`),
  ADD KEY `sun_glass_stocks_shape_id_foreign` (`shape_id`),
  ADD KEY `sun_glass_stocks_size_id_foreign` (`size_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_phone_unique` (`phone`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD KEY `users_organization_id_foreign` (`organization_id`),
  ADD KEY `users_clinic_id_foreign` (`clinic_id`);

--
-- Indexes for table `workshops`
--
ALTER TABLE `workshops`
  ADD PRIMARY KEY (`id`),
  ADD KEY `workshops_organization_id_foreign` (`organization_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `assets`
--
ALTER TABLE `assets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `asset_conditions`
--
ALTER TABLE `asset_conditions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `asset_transfers`
--
ALTER TABLE `asset_transfers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `asset_types`
--
ALTER TABLE `asset_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `billings`
--
ALTER TABLE `billings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `client_types`
--
ALTER TABLE `client_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `clinics`
--
ALTER TABLE `clinics`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `colors`
--
ALTER TABLE `colors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `contact_lens`
--
ALTER TABLE `contact_lens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `diagnoses`
--
ALTER TABLE `diagnoses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `doctor_schedules`
--
ALTER TABLE `doctor_schedules`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `frames`
--
ALTER TABLE `frames`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `frame_brands`
--
ALTER TABLE `frame_brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `frame_colors`
--
ALTER TABLE `frame_colors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `frame_materials`
--
ALTER TABLE `frame_materials`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `frame_prescriptions`
--
ALTER TABLE `frame_prescriptions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `frame_shapes`
--
ALTER TABLE `frame_shapes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `frame_sizes`
--
ALTER TABLE `frame_sizes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `frame_stocks`
--
ALTER TABLE `frame_stocks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `frame_types`
--
ALTER TABLE `frame_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `insurances`
--
ALTER TABLE `insurances`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `lens_materials`
--
ALTER TABLE `lens_materials`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `lens_powers`
--
ALTER TABLE `lens_powers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `lens_prescriptions`
--
ALTER TABLE `lens_prescriptions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `lens_types`
--
ALTER TABLE `lens_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `medicines`
--
ALTER TABLE `medicines`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `order_tracks`
--
ALTER TABLE `order_tracks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `organizations`
--
ALTER TABLE `organizations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `payment_bills`
--
ALTER TABLE `payment_bills`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `payment_details`
--
ALTER TABLE `payment_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `procedures`
--
ALTER TABLE `procedures`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `remittances`
--
ALTER TABLE `remittances`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `shapes`
--
ALTER TABLE `shapes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sizes`
--
ALTER TABLE `sizes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `statuses`
--
ALTER TABLE `statuses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sun_glasses`
--
ALTER TABLE `sun_glasses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sun_glass_stocks`
--
ALTER TABLE `sun_glass_stocks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `workshops`
--
ALTER TABLE `workshops`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `appointments_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `appointments_report_id_foreign` FOREIGN KEY (`report_id`) REFERENCES `reports` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `appointments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `assets`
--
ALTER TABLE `assets`
  ADD CONSTRAINT `assets_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `assets_condition_id_foreign` FOREIGN KEY (`condition_id`) REFERENCES `asset_conditions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `assets_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `asset_types` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `asset_conditions`
--
ALTER TABLE `asset_conditions`
  ADD CONSTRAINT `asset_conditions_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `asset_transfers`
--
ALTER TABLE `asset_transfers`
  ADD CONSTRAINT `asset_transfers_asset_id_foreign` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `asset_transfers_condition_id_foreign` FOREIGN KEY (`condition_id`) REFERENCES `asset_conditions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `asset_transfers_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `asset_transfers_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `asset_types` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `asset_types`
--
ALTER TABLE `asset_types`
  ADD CONSTRAINT `asset_types_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `billings`
--
ALTER TABLE `billings`
  ADD CONSTRAINT `billings_payment_bill_id_foreign` FOREIGN KEY (`payment_bill_id`) REFERENCES `payment_bills` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `client_types`
--
ALTER TABLE `client_types`
  ADD CONSTRAINT `client_types_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `clinics`
--
ALTER TABLE `clinics`
  ADD CONSTRAINT `clinics_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `colors`
--
ALTER TABLE `colors`
  ADD CONSTRAINT `colors_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `contact_lens`
--
ALTER TABLE `contact_lens`
  ADD CONSTRAINT `contact_lens_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `contact_lens_material_id_foreign` FOREIGN KEY (`material_id`) REFERENCES `lens_materials` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `contact_lens_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `lens_types` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `diagnoses`
--
ALTER TABLE `diagnoses`
  ADD CONSTRAINT `diagnoses_appointment_id_foreign` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `diagnoses_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `diagnoses_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `diagnoses_schedule_id_foreign` FOREIGN KEY (`schedule_id`) REFERENCES `doctor_schedules` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `diagnoses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `doctor_schedules`
--
ALTER TABLE `doctor_schedules`
  ADD CONSTRAINT `doctor_schedules_appointment_id_foreign` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `doctor_schedules_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `doctor_schedules_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `doctor_schedules_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `frames`
--
ALTER TABLE `frames`
  ADD CONSTRAINT `frames_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `frame_brands` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `frames_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `frames_material_id_foreign` FOREIGN KEY (`material_id`) REFERENCES `frame_materials` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `frames_size_id_foreign` FOREIGN KEY (`size_id`) REFERENCES `frame_sizes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `frames_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `frame_types` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `frame_colors`
--
ALTER TABLE `frame_colors`
  ADD CONSTRAINT `frame_colors_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `frame_materials`
--
ALTER TABLE `frame_materials`
  ADD CONSTRAINT `frame_materials_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `frame_prescriptions`
--
ALTER TABLE `frame_prescriptions`
  ADD CONSTRAINT `frame_prescriptions_power_id_foreign` FOREIGN KEY (`power_id`) REFERENCES `lens_powers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `frame_prescriptions_prescription_id_foreign` FOREIGN KEY (`prescription_id`) REFERENCES `lens_prescriptions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `frame_prescriptions_stock_id_foreign` FOREIGN KEY (`stock_id`) REFERENCES `frame_stocks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `frame_prescriptions_workshop_id_foreign` FOREIGN KEY (`workshop_id`) REFERENCES `workshops` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `frame_shapes`
--
ALTER TABLE `frame_shapes`
  ADD CONSTRAINT `frame_shapes_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `frame_stocks`
--
ALTER TABLE `frame_stocks`
  ADD CONSTRAINT `frame_stocks_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `frame_stocks_color_id_foreign` FOREIGN KEY (`color_id`) REFERENCES `frame_colors` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `frame_stocks_frame_id_foreign` FOREIGN KEY (`frame_id`) REFERENCES `frames` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `frame_stocks_shape_id_foreign` FOREIGN KEY (`shape_id`) REFERENCES `frame_shapes` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `frame_types`
--
ALTER TABLE `frame_types`
  ADD CONSTRAINT `frame_types_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `insurances`
--
ALTER TABLE `insurances`
  ADD CONSTRAINT `insurances_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lens_materials`
--
ALTER TABLE `lens_materials`
  ADD CONSTRAINT `lens_materials_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lens_powers`
--
ALTER TABLE `lens_powers`
  ADD CONSTRAINT `lens_powers_appointment_id_foreign` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lens_powers_diagnoisis_id_foreign` FOREIGN KEY (`diagnoisis_id`) REFERENCES `diagnoses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lens_powers_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lens_powers_schedule_id_foreign` FOREIGN KEY (`schedule_id`) REFERENCES `doctor_schedules` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lens_prescriptions`
--
ALTER TABLE `lens_prescriptions`
  ADD CONSTRAINT `lens_prescriptions_material_id_foreign` FOREIGN KEY (`material_id`) REFERENCES `lens_materials` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lens_prescriptions_power_id_foreign` FOREIGN KEY (`power_id`) REFERENCES `lens_powers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lens_prescriptions_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `lens_types` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lens_types`
--
ALTER TABLE `lens_types`
  ADD CONSTRAINT `lens_types_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `medicines`
--
ALTER TABLE `medicines`
  ADD CONSTRAINT `medicines_diagnosis_id_foreign` FOREIGN KEY (`diagnosis_id`) REFERENCES `diagnoses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `medicines_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `medicines_schedule_id_foreign` FOREIGN KEY (`schedule_id`) REFERENCES `doctor_schedules` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_appointment_id_foreign` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_frame_prescription_id_foreign` FOREIGN KEY (`frame_prescription_id`) REFERENCES `frame_prescriptions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_lens_power_id_foreign` FOREIGN KEY (`lens_power_id`) REFERENCES `lens_powers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_lens_prescription_id_foreign` FOREIGN KEY (`lens_prescription_id`) REFERENCES `lens_prescriptions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_payment_bill_id_foreign` FOREIGN KEY (`payment_bill_id`) REFERENCES `payment_bills` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_schedule_id_foreign` FOREIGN KEY (`schedule_id`) REFERENCES `doctor_schedules` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_workshop_id_foreign` FOREIGN KEY (`workshop_id`) REFERENCES `workshops` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_tracks`
--
ALTER TABLE `order_tracks`
  ADD CONSTRAINT `order_tracks_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_tracks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_tracks_workshop_id_foreign` FOREIGN KEY (`workshop_id`) REFERENCES `workshops` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `organizations`
--
ALTER TABLE `organizations`
  ADD CONSTRAINT `organizations_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `patients`
--
ALTER TABLE `patients`
  ADD CONSTRAINT `patients_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `patients_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `payment_bills`
--
ALTER TABLE `payment_bills`
  ADD CONSTRAINT `payment_bills_appointment_id_foreign` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payment_bills_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payment_bills_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payment_bills_payment_details_id_foreign` FOREIGN KEY (`payment_details_id`) REFERENCES `payment_details` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payment_bills_schedule_id_foreign` FOREIGN KEY (`schedule_id`) REFERENCES `doctor_schedules` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payment_details`
--
ALTER TABLE `payment_details`
  ADD CONSTRAINT `payment_details_appointment_id_foreign` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payment_details_client_type_id_foreign` FOREIGN KEY (`client_type_id`) REFERENCES `client_types` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payment_details_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payment_details_insurance_id_foreign` FOREIGN KEY (`insurance_id`) REFERENCES `insurances` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payment_details_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `permission_user`
--
ALTER TABLE `permission_user`
  ADD CONSTRAINT `permission_user_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `procedures`
--
ALTER TABLE `procedures`
  ADD CONSTRAINT `procedures_diagnosis_id_foreign` FOREIGN KEY (`diagnosis_id`) REFERENCES `diagnoses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `procedures_schedule_id_foreign` FOREIGN KEY (`schedule_id`) REFERENCES `doctor_schedules` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `remittances`
--
ALTER TABLE `remittances`
  ADD CONSTRAINT `remittances_bill_id_foreign` FOREIGN KEY (`bill_id`) REFERENCES `payment_bills` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `remittances_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_appointment_id_foreign` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reports_bill_id_foreign` FOREIGN KEY (`bill_id`) REFERENCES `payment_bills` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reports_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reports_diagnosis_id_foreign` FOREIGN KEY (`diagnosis_id`) REFERENCES `diagnoses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reports_frame_prescription_id_foreign` FOREIGN KEY (`frame_prescription_id`) REFERENCES `frame_prescriptions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reports_lens_prescription_id_foreign` FOREIGN KEY (`lens_prescription_id`) REFERENCES `lens_prescriptions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reports_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reports_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reports_payment_details_id_foreign` FOREIGN KEY (`payment_details_id`) REFERENCES `payment_details` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reports_power_id_foreign` FOREIGN KEY (`power_id`) REFERENCES `lens_powers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reports_schedule_id_foreign` FOREIGN KEY (`schedule_id`) REFERENCES `doctor_schedules` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shapes`
--
ALTER TABLE `shapes`
  ADD CONSTRAINT `shapes_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sizes`
--
ALTER TABLE `sizes`
  ADD CONSTRAINT `sizes_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sun_glass_stocks`
--
ALTER TABLE `sun_glass_stocks`
  ADD CONSTRAINT `sun_glass_stocks_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sun_glass_stocks_color_id_foreign` FOREIGN KEY (`color_id`) REFERENCES `colors` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sun_glass_stocks_glass_id_foreign` FOREIGN KEY (`glass_id`) REFERENCES `sun_glasses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sun_glass_stocks_shape_id_foreign` FOREIGN KEY (`shape_id`) REFERENCES `shapes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sun_glass_stocks_size_id_foreign` FOREIGN KEY (`size_id`) REFERENCES `sizes` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `users_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `workshops`
--
ALTER TABLE `workshops`
  ADD CONSTRAINT `workshops_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
